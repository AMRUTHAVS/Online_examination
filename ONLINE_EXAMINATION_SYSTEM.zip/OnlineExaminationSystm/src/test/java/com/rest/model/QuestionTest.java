/***********************************************************************

File Name		     :QuestionTest.java
Principal Author	     :Piyush Kumar
Subsystem Name               :Core Java Training
Module Name                  :
Date of First Release        :28-October-2020
Author                       :Piyush Kumar
Description                  :Test Pojo class of question


Change History

Version                     :0.1
Date(DD/MM/YYYY)            :28-October-2020
Modified by                 :Piyush Kumar
Description of change       :Initial Version

***********************************************************************/
package com.rest.model;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

/**
 * To test getters and setters
 * 
 * @see QuestionTest
 * @version 0.1
 * @author Piyush Kumar
 * 
 */
public class QuestionTest {
	// Creating object of Question
	static Question question;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		// Initialising and setting up values
		question = new Question();
		question.setExamName("Annual");
		question.setExamBranch("english");
		question.setExamDate("16/11/20");
		question.setQuestion("why");
		question.setOptionOne("1");
		question.setOptionTwo("2");
		question.setOptionThree("3");
		question.setOptionFour("4");
		question.setCorrectAnswer("4");

	}

	/**
	 * To nullify object
	 *
	 * @version 0.1
	 * @author Piyush Kumar
	 * 
	 */

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		question = null;
	}

	/**
	 * To test getter methods
	 *
	 * @version 0.1
	 * @author Piyush Kumar
	 * 
	 */
	@Test
	public void testGetDetails() {
		assertEquals("Annual", question.getExamName());
		assertEquals("english", question.getExamBranch());
		assertEquals("16/11/20", question.getExamDate());
		assertEquals("why", question.getQuestion());
		assertEquals("1", question.getOptionOne());
		assertEquals("2", question.getOptionTwo());
		assertEquals("3", question.getOptionThree());
		assertEquals("4", question.getOptionFour());
		assertEquals("4", question.getCorrectAnswer());

	}
}// class ends
