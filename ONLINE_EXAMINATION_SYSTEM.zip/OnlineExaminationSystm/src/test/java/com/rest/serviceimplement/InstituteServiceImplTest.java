/***********************************************************************

File Name		     :InstituteServiceImplTest.java
Principal Author	     :Anand k j
Subsystem Name               :Core Java Training
Module Name                  :
Date of First Release        :28-October-2020
Author                       :Anand k j
Description                  :Test class of Institute Service


Change History

Version                     :0.1
Date(DD/MM/YYYY)            :28-October-2020
Modified by                 :Anand k j
Description of change       :Initial Version

 ***********************************************************************/
package com.rest.serviceimplement;

import static org.junit.Assert.*;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import com.rest.model.Question;

/**
 * Test class for instituteServiceImpl
 *
 * @see InstituteServiceImplTest
 * @version 0.1
 * @author Anand k j
 * @since 28-October-2020
 */

public class InstituteServiceImplTest {

	// Creating object of instituteServiceImpl
	static InstituteServiceImpl institute;
	static Question question;
	static List<Question> questionList;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		institute = new InstituteServiceImpl();

		questionList = new ArrayList<Question>();

		question = new Question();
		question.setExamName("Maths");
		question.setExamBranch("9");
		question.setExamDate("19/11/20");
		question.setQuestion("why");
		question.setOptionOne("1");
		question.setOptionTwo("2");
		question.setOptionThree("3");
		question.setOptionFour("4");
		question.setCorrectAnswer("4");
		questionList.add(question);
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {

		institute = null;
	}

	/**
	 * Method to test AddInstitute
	 * 
	 * @version 0.1
	 * @author Anand k j
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 * 
	 * 
	 */
	@Test
	public void testAddInstitute() throws ClassNotFoundException, SQLException {
		assertEquals(1, institute.addInstitute("Jubilee high school", "jubilee@gmail.com", "qwertyRoot", "9771001218", "Password123"));
	}

	/**
	 * Method to test AddExam
	 * 
	 * @version 0.1
	 * @author Piyush Kumar
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 * 
	 * 
	 */
	@Test
	public void testAddExam() throws ClassNotFoundException, SQLException {
		assertEquals(1, institute.addExam("1", questionList));

	}

	/**
	 * Method to test DeleteExam
	 * 
	 * @version 0.1
	 * @author Anand k j
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 * 
	 * 
	 */

	@Test
	public void testDeleteExam() throws ClassNotFoundException, SQLException {
		assertEquals(1, institute.deleteExam("35"));

	}

	/**
	 * Method to test DeleteStudent
	 * 
	 * @version 0.1
	 * @author Anand k j
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 * 
	 */

	@Test
	public void testDeleteStudent() throws ClassNotFoundException, SQLException {
		assertEquals(1, institute.deleteStudent("34"));
	}

	/**
	 * Method to test showExam
	 * 
	 * @version 0.1
	 * @author Anand k j
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 * 
	 */
	@Test
	public void testShowExam() throws ClassNotFoundException, SQLException {
		assertNotNull(institute.showExam("10"));

	}

	/**
	 * Method to test showReport
	 * 
	 * @version 0.1
	 * @author Anand k j
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 * 
	 */
	@Test
	public void testShowReport() throws ClassNotFoundException, SQLException {
		assertNotNull(institute.showReport("1"));
	}

	/**
	 * Method to test getStudent
	 * 
	 * @version 0.1
	 * @author Anand k j
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 * 
	 */

	@Test
	public void testGetStudent() throws ClassNotFoundException, SQLException {
		assertNotNull(institute.getStudent("3"));
	}

}// class ends
