/***********************************************************************

File Name		      :StudentServiceImplTest.java
Principal Author	      :Piyush Kumar (4015432)
Subsystem Name                :Online Examination System
Module Name                   :
Date of First Release         :16-Nov-2020 10:22:23 AM
Author                        :Piyush Kumar
Description                   :To test the methods of StudentServiceImpl class.


Change History

Version                      : 0.1
Date(DD/MM/YYYY)             : 16-Nov-2020 10:22:23 AM
Modified by                  : Piyush Kumar(4015432)
Description of change        : Initial Version

 ***********************************************************************/
package com.rest.serviceimplement;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.sql.SQLException;

import org.junit.AfterClass;
import org.junit.Before;
import org.junit.Test;

import com.rest.service.StudentService;

/**
 * Description about the class.
 * 
 * 
 * @see StudentServiceImplTest.java
 * @version 0.1
 * @author Anupriya Gandhi
 * 
 */
public class StudentServiceImplTest {

	// Object of StudentServiceImpl
	static StudentService studentService;

	@Before
	public void setBeforeTest() {
		// set before each test

		studentService = new StudentServiceImpl();

	}

	/**
	 * To test getResult method.
	 * 
	 * @param
	 * @return void
	 * @see StudentServiceImplTest.java
	 * @version 0.1
	 * @author Anupriya Gandhi
	 * @throws ClassNotFoundException
	 * 
	 */
	@Test
	public void testRegisterStudent() throws SQLException, ClassNotFoundException {

		assertEquals(1, studentService.registerStudent("Jamshida", "assumption high school", "jamshida@gmail.com", "Piyu4321@",
				"8690809300", "8"));

	}

	/**
	 * To test viewSchedule method.
	 * 
	 * @param
	 * @return void
	 * @see StudentServiceImplTest.java
	 * @version 0.1
	 * @author Anupriya Gandhi
	 * 
	 */
	@Test
	public void testViewSchedule() throws SQLException, ClassNotFoundException {

		assertNotNull(studentService.viewSchedule("1", "8"));
	}

	/**
	 * To test viewReport method.
	 * 
	 * @param
	 * @return void
	 * @see StudentServiceImplTest.java
	 * @version 0.1
	 * @author Anupriya Gandhi
	 * 
	 */
	@Test
	public void testViewReport() throws ClassNotFoundException, SQLException {

		// compare result
		assertNotNull(studentService.viewReport("1"));

	}

	/**
	 * To test examToAttend method.
	 * 
	 * @param
	 * @return void
	 * @see StudentServiceImplTest.java
	 * @version 0.1
	 * @author Piyush Kumar
	 * 
	 */
	@Test
	public void testExamToAttend() throws ClassNotFoundException, SQLException {

		// compare result
		assertNotNull(studentService.examToAttend("2", "8"));

	}
	/**
	 * To test attendexam method.
	 * 
	 * @param
	 * @return void
	 * @see StudentServiceImplTest.java
	 * @version 0.1
	 * @author Piyush Kumar
	 * 
	 */
	@Test
	public void testAttendExam() throws ClassNotFoundException, SQLException {

		// compare result
		assertNotNull(studentService.attendExam("8"));

	}

	/**
	 * To test saveResult method.
	 * 
	 * @param
	 * @return void
	 * @see StudentServiceImplTest.java
	 * @version 0.1
	 * @author Piyush Kumar
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 * 
	 */
	@Test
	public void testSaveResult() throws ClassNotFoundException, SQLException {

		// compare result
		assertEquals(1, studentService.saveResult("1", "1", 10, 8));
	}

	/**
	 * To test getResult method.
	 * 
	 * 
	 * @return void
	 * @see StudentServiceImplTest.java
	 * @version 0.1
	 * @author Anupriya Gandhi
	 * 
	 */
	@Test
	public void testGetResult() throws SQLException, ClassNotFoundException {

		// compare result
		assertNotNull(studentService.getResult("1"));
	}

	@AfterClass
	public static void closeResources() throws SQLException {

		studentService = null;

	}
}// class ends
