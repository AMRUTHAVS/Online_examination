/***********************************************************************

File Name		     :LoginDaoImplTest.java
Principal Author	     :Sruthi Suresh
Subsystem Name               :Core Java Training
Module Name                  :
Date of First Release        :28-October-2020
Author                       :Sruthi Suresh
Description                  :Test class for Implementation of login class


Change History

Version                     :0.1
Date(DD/MM/YYYY)            :28-October-2020
Modified by                 :Sruthi Suresh
Description of change       :Initial Version

 ***********************************************************************/
package com.rest.daoimplement;

import static org.junit.Assert.*;

import java.sql.SQLException;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import com.rest.dao.LoginDao;

/**
 * Test class for Implementation of login class
 *
 * @see LoginDaoImpl
 * @version 0.1
 * @author Sruthi Suresh
 * @since 28-October-2020
 */
public class LoginDaoImplTest {

	static LoginDao loginDao;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		loginDao = new LoginDaoImpl();
	}

	/**
	 * To nullify object
	 * 
	 * @throws Exception
	 * @version 0.1
	 * @author Sruthi Suresh
	 * 
	 */
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		loginDao = null;
	}

	/**
	 * Test Method to userLogin
	 * 
	 * @see userLogin
	 * @param userEmail
	 * @param userPass
	 * @return String
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 * @author Sruthi Suresh
	 * 
	 */
	@Test
	public void testUserLogin() throws ClassNotFoundException, SQLException {
		assertEquals("noUser", loginDao.userLogin("noUser", "noUser"));
		assertEquals("institute", loginDao.userLogin("assumption@gmail.com", "Qwerty@123"));
		assertEquals("student", loginDao.userLogin("anupriya@gmail.com", "Qwerty@123"));
	}

}// class ends
