/***********************************************************************

File Name		     :InstituteDaoImplTest.java
Principal Author	     :Anand k j
Subsystem Name               :Core Java Training
Module Name                  :
Date of First Release        :28-October-2020
Author                       :Anand k j
Description                  :Test class for Implementation of InstituteDao


Change History

Version                     :0.1
Date(DD/MM/YYYY)            :28-October-2020
Modified by                 :Anand k j
Description of change       :Initial Version

 ***********************************************************************/
package com.rest.daoimplement;

import static org.junit.Assert.*;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import com.rest.model.Institute;
import com.rest.model.Question;

/**
 * Test class for Implementation of InstituteDao
 *
 * @see InstituteDaoImplTest
 * @version 0.1
 * @author Anand k j
 * @since 28-October-2020
 */
public class InstituteDaoImplTest {

	// Creating object of InstituteDaoImpl
	static InstituteDaoImpl instituteDao;
	// Creating object of institute
	static Institute institute;

	static Question question;
	// Creating list object of Question
	static List<Question> questionList;

	/**
	 * setUp method
	 * 
	 * @see setUp
	 * @throws Exception
	 * @author Anand k j
	 * 
	 */
	@BeforeClass
	public static void setUp() throws Exception {
		instituteDao = new InstituteDaoImpl();
		questionList = new ArrayList<Question>();
		institute = new Institute();
		institute.setInstName("Golden high school");
		institute.setInstEmail("golden@gmail.com");
		institute.setInstAddress("Qwerty Root");
		institute.setInstPhone("8910108011");
		institute.setInstPass("Password@1234");
		question = new Question();
		question.setExamName("English");
		question.setExamBranch("8");
		question.setExamDate("19/11/20");
		question.setQuestion("why");
		question.setOptionOne("1");
		question.setOptionTwo("2");
		question.setOptionThree("3");
		question.setOptionFour("4");
		question.setCorrectAnswer("4");
		questionList.add(question);

	}

	/**
	 * To nullify objet
	 * 
	 * @see tearDownAfterClass
	 * @throws Exception
	 * @author Anand k j
	 * @since 28-October-2020
	 */

	@AfterClass
	public static void tearDown() throws Exception {
		instituteDao = null;
	}

	/**
	 * Test method to add an institution
	 *
	 * @see addInstitute
	 * @param institute
	 * @return integer value
	 * @throws Exception
	 * @version 0.1
	 * @author Anand k j
	 * @since 28-October-2020
	 */
	@Test
	public void testAddInstitute() throws ClassNotFoundException, SQLException {
		assertEquals(1, instituteDao.addInstitute(institute));

	}

	/**
	 * Test method to add an institution
	 *
	 * @see addInstitute
	 * @param institute
	 * @return integer value
	 * @throws Exception
	 * @version 0.1
	 * @author Anand k j
	 * @since 28-October-2020
	 */
	@Test
	public void testAddInstituteException() throws ClassNotFoundException, SQLException {
		assertEquals(0, instituteDao.addInstitute(institute));

	}

	/**
	 * Test Method to getInstitute
	 * 
	 * @see getInstitute
	 * @param instEmail
	 * @return ResultSet
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 * @author Anand k j
	 */
	@Test
	public void testGetInstitute() throws ClassNotFoundException, SQLException {
		assertNotNull(instituteDao.getInstitute("abc@gmail.com"));
	}

	/**
	 * Test Method to addExam
	 * 
	 * @see addExam
	 * @param instituteId
	 * @param questionList
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 * @author Piyush Kumar
	 */
	@Test
	public void testAddExam() throws ClassNotFoundException, SQLException {
		assertEquals(1, instituteDao.addExam("1", questionList));
	}

	/**
	 * Test Method to deleteExams
	 * 
	 * @see deleteExams
	 * @param examId
	 * @return int
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 * @author Anand k j
	 */
	@Test
	public void testDeleteExams() throws ClassNotFoundException, SQLException {
		assertEquals(1, instituteDao.deleteExams("35"));
	}

	/**
	 * Test Method to viewExam
	 * 
	 * @see viewExam
	 * @param instituteId
	 * @return Resultset
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 * @author Anand k j
	 */
	@Test
	public void testViewExam() throws ClassNotFoundException, SQLException {
		assertNotNull(instituteDao.viewExam("7"));

	}

	/**
	 * Test Method to viewStudent
	 * 
	 * @see viewStudent
	 * @param instituteId
	 * @param studentBranch
	 * @return ResultSet
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 * @author Anand k j
	 */
	@Test
	public void testViewStudent() throws ClassNotFoundException, SQLException {
		assertNotNull(instituteDao.viewStudent("3", "9"));

	}

	/**
	 * Test Method to deleteStudent
	 * 
	 * @see deleteStudent
	 * @param examId
	 * @return int
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 * @author Anand k j
	 */
	@Test
	public void testDeleteStudent() throws ClassNotFoundException, SQLException {
		assertEquals(1, instituteDao.deleteStudent("30"));

	}

	/**
	 * Test Method to showExam
	 * 
	 * @see showExam
	 * @param instituteId
	 * @return resultset
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 * @author Anand k j
	 */
	@Test
	public void testShowExam() throws ClassNotFoundException, SQLException {
		assertNotNull(instituteDao.showExam("7"));
	}

	/**
	 * Test Method to showReport
	 * 
	 * @see showReport
	 * @param examId
	 * @return ResultSet
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 * @author Anand k j
	 */
	@Test
	public void testShowReport() throws ClassNotFoundException, SQLException {
		assertNotNull(instituteDao.showReport("1"));

	}

	/**
	 * Test Method to getStudent
	 * 
	 * @see getStudent
	 * @param studentId
	 * @return Resultset
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 * @author Anand k j
	 */
	@Test
	public void testGetStudent() throws ClassNotFoundException, SQLException {
		assertNotNull(instituteDao.getStudent("3"));
	}

}// class ends
