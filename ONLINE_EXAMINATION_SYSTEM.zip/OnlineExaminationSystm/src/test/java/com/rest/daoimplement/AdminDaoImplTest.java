/***********************************************************************

File Name		     :AdminDaoImplTest.java
Principal Author	     :Amrutha v s
Subsystem Name               :Core Java Training
Module Name                  :
Date of First Release        :28-October-2020
Author                       :Amrutha v s
Description                  :Test class for Implementation of AdminDao


Change History

Version                     :0.1
Date(DD/MM/YYYY)            :28-October-2020
Modified by                 :Amrutha v s
Description of change       :Initial Version

***********************************************************************/
package com.rest.daoimplement;

import static org.junit.Assert.*;

import java.sql.SQLException;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

/**
 * Test class for Implementation ofAdminDao
 * 
 * @see AdminDaoImpl
 * @version 0.1
 * @author Amrutha v s
 * 
 */
public class AdminDaoImplTest {
	// Creating object of AdminDaoImpl
	static AdminDaoImpl admin;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		admin = new AdminDaoImpl();
	}

	/**
	 * To nullify object
	 * 
	 * @throws Exception
	 * @version 0.1
	 * @author Amrutha v s
	 * 
	 */
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		admin = null;
	}

	/**
	 * Test Method to ViewInstitute
	 *
	 * @version 0.1
	 * @author Amrutha v s
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 * 
	 */
	@Test
	public void testViewInstitute() throws ClassNotFoundException, SQLException {
		assertNotNull(admin.viewInstitute());
	}

	/**
	 * Test Method to DeleteInstitute
	 *
	 * @version 0.1
	 * @author Amrutha v s
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 * 
	 */
	@Test
	public void testDeleteInstituite() throws ClassNotFoundException, SQLException {
		assertEquals(1, admin.deleteInstituite("44"));
	}

}// class ends
