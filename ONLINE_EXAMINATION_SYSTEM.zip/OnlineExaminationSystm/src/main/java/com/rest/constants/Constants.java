/***********************************************************************

File Name				   :Constants.java
Principal Author			   :Amrutha v s
Subsystem Name                :Core Java Training
Module Name                   :
Date of First Release         :28-October-2020
Author                           : Amrutha v s
Description                :Class that contains constant values.


Change History

Version                      :0.1
Date(DD/MM/YYYY)            :28-October-2020
Modified by                 :Amrutha v s
Description of change       :Initial Version

 ***********************************************************************/
package com.rest.constants;

/**
 * Class that contains constant values.
 * 
 * @return
 * @param
 * @see Constants
 * @version 0.1
 * @author Amrutha v s
 */
public class Constants {
	private Constants()
	{
	
	}
	// defining constants
		public static final String URL = "jdbc:mysql://localhost:3306/onlineexaminationsystem";
		public static final String USER = "root";
		public static final String PASS = "root";
}// class ends.
