/***********************************************************************

File Name		     :AdminDao.java
Principal Author	     :Amrutha v s
Subsystem Name               :Core Java Training
Module Name                  :
Date of First Release        :28-October-2020
Author                       :Amrutha v s
Description                  :Interface of AdminDao


Change History

Version                     :0.1
Date(DD/MM/YYYY)            :28-October-2020
Modified by                 :Amrutha v s
Description of change       :Initial Version

***********************************************************************/
package com.rest.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Interface of Admin
 * 
 * @see AdminDao
 * @version 0.1
 * @author Amrutha v s
 * 
 */
public interface AdminDao {
	/**
	 * Method of viewInstitute
	 * 
	 * @return ResultSet
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 * @author Amrutha v s
	 */
	public ResultSet viewInstitute() throws SQLException, ClassNotFoundException;

	/**
	 * Method of deleteInstitute
	 * 
	 * @param instituteId
	 * @return int
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 * @author Amrutha v s
	 */
	public int deleteInstituite(String instituteId) throws SQLException, ClassNotFoundException;
}// interface ends