/***********************************************************************

File Name		      :AdminServiceImpl.java
Principal Author	      :Amrutha v s
Subsystem Name                :Core Java Training
Module Name                   :
Date of First Release         :28-October-2020
Author                        :Amrutha v s
Description                   :Implementation class of Admin Service


Change History

Version                     :0.1
Date(DD/MM/YYYY)            :28-October-2020
Modified by                 :Amrutha v s
Description of change       :Initial Version

***********************************************************************/
package com.rest.serviceimplement;

import java.sql.SQLException;
import com.rest.dao.AdminDao;
import com.rest.daoimplement.AdminDaoImpl;
import com.rest.service.AdminService;

/**
 * Implementation class of Admin service
 * 
 * @return
 * @param
 * @see AdminServiceImpl
 * @version 0.1
 * @author Amrutha v s
 * 
 */
public class AdminServiceImpl implements AdminService {
	// Creating object of AdminDao using upcasting
	AdminDao adminDao = new AdminDaoImpl();

	/**
	 * Method For calling deleteInstitute function of the dao layer
	 * 
	 * @return int
	 * @param instituteId
	 * @see deleteInstitute
	 * @version 0.1
	 * @author Amrutha v s
	 * 
	 */
	public int deleteInstitute(String instituteId) throws ClassNotFoundException, SQLException {
		// Calling the deleteInstitute function from dao layer
		return adminDao.deleteInstituite(instituteId);
	}
}// class Ends
