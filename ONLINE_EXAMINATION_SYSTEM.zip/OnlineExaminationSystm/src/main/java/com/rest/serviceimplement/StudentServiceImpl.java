/***********************************************************************

File Name		      :StudentServiceImpl.java
Principal Author	      :Amrutha v s
Subsystem Name                :Core Java Training
Module Name                   :
Date of First Release         :28-October-2020
Author                        :Amrutha v s
Description                   :This class implements the business logic for students.


Change History

Version                      :0.1
Date(DD/MM/YYYY)            :28-October-2020
Modified by                 :Amrutha v s
Description of change       :Initial Version

***********************************************************************/
package com.rest.serviceimplement;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.rest.dao.StudentDao;
import com.rest.daoimplement.StudentDaoImpl;
import com.rest.model.Student;
import com.rest.service.StudentService;

/**
 * Implements the methods of studentService class.
 * 
 * @return
 * @param
 * @see Program1
 * @version 0.1
 * @author Anupriya Gandhi
 * @since 28-October-2020
 */
public class StudentServiceImpl implements StudentService {

	// object of studentDao class
	StudentDao studentDao = new StudentDaoImpl();

	// array list of students to save student list
	List<Student> studentList = new ArrayList<Student>();

	/**
	 * method to add a new student details in database.
	 *
	 * @see registerStudent
	 * @param studName
	 * @param studInsId
	 * @param studEmail
	 * @param studPass
	 * @param studMob
	 * @return integer value
	 * @version 0.1
	 * @author Sruthi Surest
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 * 
	 */

	public int registerStudent(String studName, String studInstitution, String studEmail, String studPass,
			String studMob, String studClass) throws ClassNotFoundException, SQLException {

		// create a student object
		Student student = new Student();

		// initialize the values of student attributes
		student.setStudName(studName);
		student.setStudInstitution(studInstitution);
		student.setStudEmail(studEmail);
		student.setStudPass(studPass);
		student.setStudMob(studMob);
		student.setStudClass(studClass);

		// add student in list
		studentList.add(student);

		// add student in database
		return studentDao.registerStudent(student);
	}

	/**
	 * To view the schedules of exam.
	 * 
	 * @return ResultSet
	 * @param institudeId,studentBranch
	 * @see viewSchedule
	 * @version 0.1
	 * @author Anupriya Gandhi
	 * 
	 */
	public ResultSet viewSchedule(String institudeId, String studentBranch)
			throws SQLException, ClassNotFoundException {

		// fetch the schedule from database
		return studentDao.viewSchedule(institudeId, studentBranch);

	}

	/**
	 * To get the result of the student.
	 * 
	 * @return ResultSet
	 * 
	 * @param studentId
	 * @see getResult
	 * @version 0.1
	 * @author Anupriya Gandhi
	 * 
	 */
	public ResultSet getResult(String studentId) throws SQLException, ClassNotFoundException {

		// get the result from database
		return studentDao.getResult(studentId);

	}

	/**
	 * To view the report of the student.
	 * 
	 * @return ResultSet
	 * @param examId
	 * @see viewReport
	 * @version 0.1
	 * @author Anupriya Gandhi
	 * 
	 */
	public ResultSet viewReport(String examId) throws SQLException, ClassNotFoundException {

		// fetch the report from database
		return studentDao.viewReport(examId);

	}

	/**
	 * To display exam yet to be attend by students.
	 * 
	 * @param instituteId
	 * @param branch
	 * @return ResultSet
	 * @see examToAttend
	 * @version 0.1
	 * @author Anupriya Gandhi
	 * 
	 */
	public ResultSet examToAttend(String instituteId, String branch) throws SQLException, ClassNotFoundException {

		// fetch the exams from database on particular date
		return studentDao.examToAttend(instituteId, branch);
	}

	/**
	 * To fetch questions to attend exam by students.
	 * 
	 * @param examId
	 * @return ResultSet
	 * @see attendExam
	 * @version 0.1
	 * @author Anupriya Gandhi
	 * 
	 */
	public ResultSet attendExam(String examId) throws ClassNotFoundException, SQLException {

		// fetch questions to attend exam
		return studentDao.attendExam(examId);
	}

	/**
	 * To save the result of student in database.
	 * 
	 * @param examId
	 * @param studentId
	 * @param totalmarks
	 * @param obtainedMarks
	 * @return int
	 * @see saveResult
	 * @version 0.1
	 * @author Anupriya Gandhi
	 * 
	 */
	public int saveResult(String examId, String studentId, int totalmarks, int obtainedMarks)
			throws ClassNotFoundException, SQLException {

		// string object to save status
		String resultStatus = "Pass";

		// check if student is pass
		if (obtainedMarks < 3) {
			// update status
			resultStatus = "Fail";
		}

		// save the result in database
		return studentDao.saveResult(examId, studentId, totalmarks, obtainedMarks, resultStatus);

	}

}// class ends.
