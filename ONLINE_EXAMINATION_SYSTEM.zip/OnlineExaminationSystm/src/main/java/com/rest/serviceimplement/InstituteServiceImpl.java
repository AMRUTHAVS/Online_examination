/***********************************************************************

File Name		     :InstituteServiceImpl.java
Principal Author	     :Anand k j
Subsystem Name               :Core Java Training
Module Name                  :
Date of First Release        :28-October-2020
Author                       :Anand k j
Description                  :Implementation for class of Institute Service


Change History

Version                     :0.1
Date(DD/MM/YYYY)            :28-October-2020
Modified by                 :Anand k j
Description of change       :Initial Version

 ***********************************************************************/
package com.rest.serviceimplement;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.rest.dao.InstituteDao;
import com.rest.daoimplement.InstituteDaoImpl;
import com.rest.model.Institute;
import com.rest.model.Question;
import com.rest.service.InstituteService;

/**
 * Service impl class for institution
 *
 * @see InstituteServiceImpl
 * @version 0.1
 * @author Anand k j
 * 
 */
public class InstituteServiceImpl implements InstituteService {
	// Creating object of Institutedao using upcasting
	InstituteDao daoService = new InstituteDaoImpl();
	// Creating a object of list to store list of institutes
	List<Institute> instList = new ArrayList<Institute>();
	// Creating object of institute
	Institute institute;

	/**
	 * method to add an institution
	 *
	 * @see addInstitute
	 * @param instName
	 * @param instEmail
	 * @param instAddress
	 * @param instPhone
	 * @param instPass
	 * @return integer value
	 * @version 0.1
	 * @author Anand k j
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 * 
	 */
	public int addInstitute(String instName, String instEmail, String instAddress, String instPhone, String instPass)
			throws ClassNotFoundException, SQLException {
		// initialising object
		institute = new Institute();
		institute.setInstName(instName);
		institute.setInstEmail(instEmail);
		institute.setInstAddress(instAddress);
		institute.setInstPass(instPass);
		institute.setInstPhone(instPhone);
		instList.add(institute);
		// Calling addInstitute function from daoimpl layer
		return daoService.addInstitute(institute);
	}

	/**
	 * Method to add an exam
	 * 
	 * @param instituteId
	 * @param questionList
	 * @return int
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 * @version 0.1
	 * @author Anand k j
	 * 
	 * 
	 */
	public int addExam(String instituteId, List<Question> questionList) throws ClassNotFoundException, SQLException {
		
		// Calling addExam function from daoimpl layer
		return daoService.addExam(instituteId, questionList);

	}

	/**
	 * Method to delete exam
	 * 
	 * @param examId
	 * @return int
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 * @version 0.1
	 * @author Anand k j
	 * 
	 */
	public int deleteExam(String examId) throws ClassNotFoundException, SQLException {
		// Calling deleteExams function from daoimpl layer
		return daoService.deleteExams(examId);
	}

	/**
	 * Method to delete student
	 * 
	 * @param studentId
	 * @return int
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 * @version 0.1
	 * @author Anand k j
	 * 
	 */
	public int deleteStudent(String studentId) throws ClassNotFoundException, SQLException {
		// Initialising variable
		int result = 0;
		// Calling deleteStudent function from daoimpl layer
		result = daoService.deleteStudent(studentId);
		return result;
	}

	/**
	 * Method to Show exam
	 * 
	 * @param instituteId
	 * @return resultset
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 * @version 0.1
	 * @author Anand k j
	 * 
	 */
	public ResultSet showExam(String instituteId) throws ClassNotFoundException, SQLException {
		// Calling showExam function from daoimpl layer
		return daoService.showExam(instituteId);
	}

	/**
	 * Method to show report
	 * 
	 * @param examId
	 * @return resultset
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 * @version 0.1
	 * @author Anand k j
	 * 
	 */
	public ResultSet showReport(String examId) throws ClassNotFoundException, SQLException {
		// Calling showReport function from daoimpl layer
		return daoService.showReport(examId);
	}

	/**
	 * Method to get student
	 * 
	 * @param studentId
	 * @return resultset
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 * @version 0.1
	 * @author Anand k j
	 * 
	 */
	public ResultSet getStudent(String studentId) throws ClassNotFoundException, SQLException {
		// Calling getStudent function from daoimpl layer
		return daoService.getStudent(studentId);
	}
}// class ends
