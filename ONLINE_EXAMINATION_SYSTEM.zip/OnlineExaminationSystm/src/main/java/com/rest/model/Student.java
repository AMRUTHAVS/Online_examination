/***********************************************************************

File Name		     :Student.java
Principal Author	     :Amrutha v s
Subsystem Name               :Core Java Training
Module Name                  :
Date of First Release        :28-October-2020
Author                       :Amrutha v s
Description                  :Pojo class of Students


Change History

Version                     :0.1
Date(DD/MM/YYYY)            :28-October-2020
Modified by                 :Amrutha v s
Description of change       :Initial Version

***********************************************************************/
package com.rest.model;

/**
 * To setup getters and setters
 * 
 * @see Student
 * @version 0.1
 * @author Amrutha v s
 * 
 */
public class Student {
	// Instance Variables
	private String studName;
	private String studInstitution;
	private String studEmail;
	private String studPass;
	private String studMob;
	private String studClass;

	// Generating the getters and setters.

	/**
	 * @see getStudName
	 * @version 0.1
	 * @author Amrutha v s
	 * 
	 * @return the studName
	 */
	public String getStudName() {
		return studName;
	}

	/**
	 * the studName to set
	 * 
	 * @see setStudName
	 * @version 0.1
	 * @author Amrutha v s
	 * 
	 * @param studName
	 */
	public void setStudName(String studName) {
		this.studName = studName;
	}

	/**
	 * @see getStudInsId
	 * @version 0.1
	 * @author Amrutha v s
	 * 
	 * @return the studInsId
	 */
	public String getStudInstitution() {
		return studInstitution;
	}

	/**
	 * the studInsId to set
	 * 
	 * @see setStudInsId
	 * @version 0.1
	 * @author Amrutha v s
	 * 
	 * @param studInsId
	 */
	public void setStudInstitution(String studInstitution) {
		this.studInstitution = studInstitution;
	}

	/**
	 * @see getStudEmail
	 * @version 0.1
	 * @author Amrutha v s
	 * 
	 * @return the studEmail
	 */
	public String getStudEmail() {
		return studEmail;
	}

	/**
	 * the studEmail to set
	 * 
	 * @see setStudEmail
	 * @version 0.1
	 * @author Amrutha v s
	 * 
	 * @param studEmail
	 */
	public void setStudEmail(String studEmail) {
		this.studEmail = studEmail;
	}

	/**
	 * @see getStudPass
	 * @version 0.1
	 * @author Amrutha v s
	 * 
	 * @return the studPass
	 */
	public String getStudPass() {
		return studPass;
	}

	/**
	 * the studPass to set
	 * 
	 * @see setStudPass
	 * @version 0.1
	 * @author Amrutha v s
	 * 
	 * @param studPass
	 */
	public void setStudPass(String studPass) {
		this.studPass = studPass;
	}

	/**
	 * @see getStudMob
	 * @version 0.1
	 * @author Amrutha v s
	 * 
	 * @return the studMob
	 */
	public String getStudMob() {
		return studMob;
	}

	/**
	 * the studMob to set
	 * 
	 * @see setStudMob
	 * @version 0.1
	 * @author Amrutha v s
	 * 
	 * @param studMob
	 */
	public void setStudMob(String studMob) {
		this.studMob = studMob;
	}

	/**
	 * @see getStudClass
	 * @version 0.1
	 * @author Amrutha v s
	 * 
	 * @return the studMob
	 */
	public String getStudClass() {
		return studClass;
	}

	/**
	 * the studMob to set
	 * 
	 * @see setStudMob
	 * @version 0.1
	 * @author Amrutha v s
	 * 
	 * @param studMob
	 */
	public void setStudClass(String studClass) {
		this.studClass = studClass;
	}
} // class ends