/***********************************************************************

File Name		     :Institute.java
Principal Author	     :Sruthi Suresh
Subsystem Name               :Core Java Training
Module Name                  :
Date of First Release        :28-October-2020
Author                       :Sruthi Suresh
Description                  :Pojo class of Institutes


Change History

Version                     :0.1
Date(DD/MM/YYYY)            :28-October-2020
Modified by                 :Sruthi Suresh
Description of change       :Initial Version

 ***********************************************************************/
package com.rest.model;

/**
 * To setup getters and setters
 *
 * @see Institute
 * @version 0.1
 * @author Sruthi Suresh
 */
public class Institute {
	// creating instance data members
	private String instName;
	private String instEmail;
	private String instPhone;
	private String instAddress;
	private String instPass;

	/**
	 * Getter method to get institution name
	 *
	 * @see getInstName
	 * @return instName
	 * @version 0.1
	 * @author Sruthi Suresh
	 * 
	 */
	public String getInstName() {
		return instName;
	}

	/**
	 * Setter method to set institution name
	 *
	 * @see setInstName
	 * @param instName
	 * @version 0.1
	 * @author Sruthi Suresh
	 * 
	 */
	public void setInstName(String instName) {
		this.instName = instName;
	}

	/**
	 * Getter method to get institution email
	 *
	 * @see getInstEmail
	 * @return instEmail
	 * @version 0.1
	 * @author Sruthi Suresh
	 * 
	 */
	public String getInstEmail() {
		return instEmail;
	}

	/**
	 * Setter method to set institution email id
	 *
	 * @see setInstEmail
	 * @param instEmail
	 * @version 0.1
	 * @author Sruthi Suresh
	 * 
	 */
	public void setInstEmail(String instEmail) {
		this.instEmail = instEmail;
	}

	/**
	 * Getter method to get institution phone number
	 *
	 * @see getInstPhone
	 * @return instPhone
	 * @version 0.1
	 * @author Sruthi Suresh
	 * 
	 */
	public String getInstPhone() {
		return instPhone;
	}

	/**
	 * Setter method to set institution phone
	 *
	 * @see setInstPhone
	 * @param instPhone
	 * @version 0.1
	 * @author Sruthi Suresh
	 * 
	 */
	public void setInstPhone(String instPhone) {
		this.instPhone = instPhone;
	}

	/**
	 * Getter method to get institution address
	 *
	 * @see getInstAddress
	 * @return instAddress
	 * @version 0.1
	 * @author Sruthi Suresh
	 * 
	 */
	public String getInstAddress() {
		return instAddress;
	}

	/**
	 * Setter method to set institution address
	 *
	 * @see setInstAddress
	 * @param instAddress
	 * @version 0.1
	 * @author Sruthi Suresh
	 * 
	 */
	public void setInstAddress(String instAddress) {
		this.instAddress = instAddress;
	}

	/**
	 * Getter method to get institution password
	 *
	 * @see getInstPass
	 * @return instPass
	 * @version 0.1
	 * @author Sruthi Suresh
	 * 
	 */
	public String getInstPass() {
		return instPass;
	}

	/**
	 * Setter method to set institution password
	 *
	 * @see setInstPass
	 * @param instPass
	 * @version 0.1
	 * @author Sruthi Suresh
	 * 
	 */
	public void setInstPass(String instPass) {
		this.instPass = instPass;
	}

}// class ends
