/***********************************************************************

File Name		      :DbConnection.java
Principal Author	      :Amrutha v s
Subsystem Name                :Core Java Training
Module Name                   :
Date of First Release         :28-October-2020
Author                        :Amrutha v s
Description                   :To set up the JDBC connection using singleton class.


Change History

Version                     :0.1
Date(DD/MM/YYYY)            :28-October-2020
Modified by                 :Amrutha v s
Description of change       :Initial Version

 ***********************************************************************/
package com.rest.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.rest.constants.Constants;

/**
 * To set up the JDBC connection using singleton class.
 * 
 * @return
 * @param
 * @see Program1
 * @version 0.1
 * @author Amrutha v s
 * @since 28-October-2020
 */
public class DbConnection {
	// instance variables and objects
	private static DbConnection dbInstance;
	private Connection connection;

	/**
	 * Creating a private constructor to call the connection object in other
	 * classes.
	 * 
	 * @see DBConnection
	 * @version 0.1
	 * @throws ClassNotFoundException,SQLException
	 * @author Amrutha v s
	 * @throws SQLException
	 * 
	 */
	public DbConnection() throws ClassNotFoundException, SQLException {
		// Registering your driver.
		Class.forName("com.mysql.cj.jdbc.Driver");
		// Creating the connection.
		this.connection = DriverManager.getConnection(Constants.URL, Constants.USER, Constants.PASS);

	}

	/**
	 * To return the instance of the connection
	 * 
	 * @see Connection
	 * @return connection
	 * @version 0.1
	 * @author Amrutha v s
	 * 
	 */
	public Connection getConnection() {
		return connection;
	}

	/**
	 * Creating a static method to return the instance of the connection.
	 * 
	 * @see DBConnection
	 * @return dbInstance
	 * @version 0.1
	 * @throws ClassNotFoundException,SQLException
	 * @author Amrutha v s
	 * 
	 */
	public static DbConnection getInstance() throws ClassNotFoundException, SQLException {
		// if instance is null or is closed then create connection.
		if (dbInstance == null || dbInstance.getConnection().isClosed()) {
			dbInstance = new DbConnection();
		}
		// function which returns the instance of the connection.
		return dbInstance;
	}
}// class ends.
