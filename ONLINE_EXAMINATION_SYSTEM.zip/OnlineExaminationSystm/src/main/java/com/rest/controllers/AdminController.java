/***********************************************************************

File Name		      :AdminController.java
Principal Author	      :Amrutha v s
Subsystem Name                :Core Java Training
Module Name                   :
Date of First Release         :28-October-2020
Author                        :Amrutha v s
Description                   :Controller class of Admin


Change History

Version                     :0.1
Date(DD/MM/YYYY)            :28-October-2020
Modified by                 :Amrutha v s
Description of change       :Initial Version

***********************************************************************/
package com.rest.controllers;

import java.net.URI;
import java.net.URISyntaxException;
import java.sql.SQLException;
import java.util.logging.Logger;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.rest.service.AdminService;
import com.rest.serviceimplement.AdminServiceImpl;

/**
 * Controller class of Admin
 * 
 * @see AdminController
 * @version 0.1
 * @author Amrutha v s
 * @since 28-October-2020
 */
@Path("/admin")
public class AdminController {
	// creating object of AdminServiceimpl using upper casting
	AdminService adminService = new AdminServiceImpl();
	// creating logger class object
	Logger logger = Logger.getAnonymousLogger();

	/**
	 * controller to delete student
	 * 
	 * @return Response
	 * @param instituteId
	 * @see deleteInstitute
	 * @version 0.1
	 * @author Amrutha v s
	 * 
	 */
	@GET
	@Path("/deleteInstitute/{institueId}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response deleteInstitute(@PathParam("institueId") String institueId) {
		// declaring variable for uri
		URI uri = null;
		// calling method to delete institute and setting uri
		try {
			adminService.deleteInstitute(institueId);
			String path = "http://localhost:8080/OnlineExaminationSystm/deleteInstituteSuccess.jsp";
			uri = new URI(path);
		} catch (ClassNotFoundException e) {

			logger.info(e.getMessage());
		} catch (URISyntaxException e) {
			logger.info(e.getMessage());
		} catch (SQLException e) {
			logger.info(e.getMessage());
		} // try-catch ends
		return Response.seeOther(uri).build();
	}// deleteInstitute ends

}// class ends
