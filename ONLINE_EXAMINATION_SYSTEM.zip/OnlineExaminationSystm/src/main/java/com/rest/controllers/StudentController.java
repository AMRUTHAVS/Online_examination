/***********************************************************************

File Name		      :StudentController.java
Principal Author	      :Anupriya Gandhi
Subsystem Name                :Core Java Training
Module Name                   :
Date of First Release         :28-October-2020
Author                        :Anupriya Gandhi
Description                   :To control the rest api's of student


Change History

Version                     :0.1
Date(DD/MM/YYYY)            :28-October-2020
Modified by                 :Anupriya Gandhi
Description of change       :Initial Version

 ***********************************************************************/
package com.rest.controllers;

import java.net.URI;
import java.net.URISyntaxException;
import java.sql.SQLException;
import java.util.logging.Logger;

import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.rest.exceptions.UserAlreadyExistsException;
import com.rest.service.StudentService;
import com.rest.serviceimplement.StudentServiceImpl;

/**
 * To control student functionalities
 * 
 * @see StudentController
 * @version 0.1
 * @author Anupriya Gandhi
 */
@Path("/student")
public class StudentController {
	// creating object of StudentServiceImpl class using up casting
	StudentService studentService = new StudentServiceImpl();
	// creating object of logger class
	Logger logger = Logger.getAnonymousLogger();
	// declaring uri variable
	URI uri = null;

	/**
	 * To add students
	 * 
	 * @return Response
	 * @param name
	 *            : student name
	 * @param institution
	 *            : institution name
	 * @param class
	 *            : class name
	 * @param email
	 *            : email id
	 * @param phone
	 *            : phone number
	 * @param password
	 *            : password
	 * @see addStudent
	 * @version 0.1
	 * @author Sruthi Suresh
	 */
	@POST
	@Path("/add")
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_JSON })
	public Response addStudent(@FormParam("name") String studName, @FormParam("institution") String studInstitution,
			@FormParam("class") String studClass, @FormParam("email") String studEmail,
			@FormParam("phone") String studMob, @FormParam("password") String studPass)
			throws ClassNotFoundException, SQLException, URISyntaxException {

		int result = 0;
		String message = null;
		// calling registerStudent method and setting uri according to the result
		if (studName != null && studInstitution != null && studClass != null && studEmail != null && studMob != null
				&& studPass != null) {
			result = studentService.registerStudent(studName, studInstitution, studEmail, studPass, studMob, studClass);
		} // if ends

		try {

			if (result == 1) {
				message = "success";

			} else {
				throw new UserAlreadyExistsException("exaception thrown");

			} // if-else ends
		} catch (UserAlreadyExistsException e) {
			message = "failed";
		} // try catch ends
		String path = "http://localhost:8080/OnlineExaminationSystm/login.jsp?msg=" + message;
		uri = new URI(path);
		return Response.seeOther(uri).build();
	}// add Student ends

}// class ends