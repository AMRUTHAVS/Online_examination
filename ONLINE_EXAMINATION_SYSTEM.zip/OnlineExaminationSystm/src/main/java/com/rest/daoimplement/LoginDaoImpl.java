/***********************************************************************

File Name		     :LoginDaoImpl.java
Principal Author	     :Sruthi Suresh
Subsystem Name               :Core Java Training
Module Name                  :
Date of First Release        :28-October-2020
Author                       :Sruthi Suresh
Description                  :Implementation for login class


Change History

Version                     :0.1
Date(DD/MM/YYYY)            :28-October-2020
Modified by                 :Sruthi Suresh
Description of change       :Initial Version

 ***********************************************************************/
package com.rest.daoimplement;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.rest.dao.LoginDao;
import com.rest.util.DbConnection;

/**
 * Implementation for login class
 *
 * @see LoginDaoImpl
 * @version 0.1
 * @author Sruthi Suresh
 * @since 28-October-2020
 */
public class LoginDaoImpl implements LoginDao {
	// Creating reference variable
	PreparedStatement ps;
	String query;
	ResultSet rs;

	/**
	 * Method to userLogin
	 * 
	 * @see userLogin
	 * @param userEmail
	 * @param userPass
	 * @return String
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 * @author Sruthi Suresh
	 * 
	 */
	public String userLogin(String userEmail, String userPass) throws SQLException, ClassNotFoundException {
		// checking whether institute or not
		query = "select * from institutes where institute_email=? and institute_password=?";

		// Calling database connection
		ps = DbConnection.getInstance().getConnection().prepareStatement(query);
		ps.setString(1, userEmail);
		ps.setString(2, userPass);
		rs = ps.executeQuery();
		// if institute then return "institute"
		if (rs.next())
			return "institute";
		// checking whether student or not
		query = "select * from students where student_email=? and student_password=?";
		ps = DbConnection.getInstance().getConnection().prepareStatement(query);
		ps.setString(1, userEmail);
		ps.setString(2, userPass);
		rs = ps.executeQuery();
		// if institute then return "student"
		if (rs.next())
			return "student";
		return "noUser";
	}
}// class ends