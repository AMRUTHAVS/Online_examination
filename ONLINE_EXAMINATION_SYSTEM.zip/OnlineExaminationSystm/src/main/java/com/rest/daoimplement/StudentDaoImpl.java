/***********************************************************************

File Name		      :Program1.java
Principal Author	      : Anupriya Gandhi
Subsystem Name                :Core Java Training
Module Name                   :
Date of First Release         :28-October-2020
Author                        : Anupriya Gandhi
Description                   :Class for performing database-related logic for the Student module


Change History

Version                      :0.1
Date(DD/MM/YYYY)            :28-October-2020
Modified by                 : Anupriya Gandhi
Description of change       :Initial Version

***********************************************************************/
package com.rest.daoimplement;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Logger;

import com.rest.dao.StudentDao;
import com.rest.model.Student;
import com.rest.util.DbConnection;

/**
 * Class for performing database-related logic for the Student module
 * 
 * @return
 * @param
 * @see Program1
 * @version 0.1
 * @author Anupriya Gandhi
 * @since 28-October-2020
 */
public class StudentDaoImpl implements StudentDao {
	// Creating the reference variables.
	Statement statement = null;
	PreparedStatement preparedStatement = null;
	ResultSet rs = null;
	String sql = null;

	// creating logger
	Logger log = Logger.getAnonymousLogger();

	/**
	 * To register student.
	 * 
	 * @return int
	 * @param student
	 * @see registerStudent
	 * @version 0.1
	 * @author Sruthi Suresh
	 * 
	 */
	public int registerStudent(Student student) throws ClassNotFoundException, SQLException {
		// initializing query
		sql = "select * from students where student_email=?";
		preparedStatement = DbConnection.getInstance().getConnection().prepareStatement(sql);
		// setting values in parameterized query
		preparedStatement.setString(1, student.getStudEmail());
		// executing query
		rs = preparedStatement.executeQuery();
		// returning zero if student with the entered email is already registered
		if (rs.next())
			return 0;
		sql = "select * from institutes where institute_name=?";
		preparedStatement = DbConnection.getInstance().getConnection().prepareStatement(sql);
		preparedStatement.setString(1, student.getStudInstitution());
		rs = preparedStatement.executeQuery();
		rs.next();
		sql = "insert into students(student_name,student_institute_id,student_branch,student_email,student_password,student_mob)values (?,?,?,?,?,?)";
		preparedStatement = DbConnection.getInstance().getConnection().prepareStatement(sql);
		// set values of query
		preparedStatement.setString(1, student.getStudName());
		preparedStatement.setString(2, rs.getString(1));
		preparedStatement.setString(3, student.getStudClass());
		preparedStatement.setString(4, student.getStudEmail());
		preparedStatement.setString(5, student.getStudPass());
		preparedStatement.setString(6, student.getStudMob());
		// returning if student with the entered email is not registered
		return preparedStatement.executeUpdate();

	}// registerStudent ends

	/**
	 * To get student.
	 * 
	 * @return ResultSet
	 * @param studEmail
	 * @see getStudent
	 * @version 0.1
	 * @author Anupriya Gandhi
	 * 
	 */
	public ResultSet getStudent(String studEmail) throws SQLException, ClassNotFoundException {
		// initializing query
		sql = "select * from students where student_email=?";
		preparedStatement = DbConnection.getInstance().getConnection().prepareStatement(sql);
		// set values of query
		preparedStatement.setString(1, studEmail);
		// executing query
		rs = preparedStatement.executeQuery();
		rs.next();
		// returning resultset
		return rs;
	}// getStudent ends

	/**
	 * To view the schedule.
	 * 
	 * @return ResultSet
	 * @param institudeId,studentBranch
	 * @see viewSchedule
	 * @version 0.1
	 * @author Anupriya Gandhi
	 * 
	 */
	public ResultSet viewSchedule(String institudeId, String studentBranch)
			throws SQLException, ClassNotFoundException {
		statement = DbConnection.getInstance().getConnection().createStatement();
		// getting current date
		long millis = System.currentTimeMillis();
		Date date = new Date(millis);
		// initializing query
		sql = "select * from exam where institute_id ='" + institudeId + "'AND branch ='" + studentBranch
				+ "'AND exam_date >= '" + date + "'";
		// returning result of query
		return statement.executeQuery(sql);

	}// viewSchedule ends

	/**
	 * To get the result of the student.
	 * 
	 * @return ResultSet
	 * @param studentId
	 * @see getResult
	 * @version 0.1
	 * @author Anupriya Gandhi
	 * 
	 */
	public ResultSet getResult(String studentId) throws ClassNotFoundException, SQLException {
		// initializing query
		sql = "select * from result where student_id=?";
		preparedStatement = DbConnection.getInstance().getConnection().prepareStatement(sql,
				ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
		// set values of query
		preparedStatement.setString(1, studentId);
		// returning result of query
		return preparedStatement.executeQuery();
	}// getResult ends

	/**
	 * To view the report of the student.
	 * 
	 * @return ResultSet
	 * @param examId
	 * @see viewReport
	 * @version 0.1
	 * @author Anupriya Gandhi
	 * 
	 */
	public ResultSet viewReport(String examId) throws ClassNotFoundException, SQLException {
		statement = DbConnection.getInstance().getConnection().createStatement();
		// initializing query
		sql = "select * from exam where exam_id = '" + examId + "'";
		// returning result of query
		return statement.executeQuery(sql);

	}// viewReport ends

	/**
	 * To view the report of the student.
	 * 
	 * @return ResultSet
	 * @param instituteId,
	 *            branch
	 * @see examToAttend
	 * @version 0.1
	 * @author Anupriya Gandhi
	 * 
	 */
	public ResultSet examToAttend(String instituteId, String branch) throws SQLException, ClassNotFoundException {
		// getting current date
		long millis = System.currentTimeMillis();
		Date date = new Date(millis);
		// initializing query
		sql = "select * from exam where institute_id=? and branch=? and exam_date = '" + date + "'";
		preparedStatement = DbConnection.getInstance().getConnection().prepareStatement(sql);
		// set values of query
		preparedStatement.setString(1, instituteId);
		preparedStatement.setString(2, branch);
		// returning result of query
		return preparedStatement.executeQuery();
	}// examToAttend ends

	/**
	 * To attend the exam by student.
	 * 
	 * @return ResultSet
	 * @param examId
	 * @see attendExam
	 * @version 0.1
	 * @author Anupriya Gandhi
	 * 
	 */
	public ResultSet attendExam(String examId) throws ClassNotFoundException, SQLException {
		statement = DbConnection.getInstance().getConnection().createStatement();

		// sql query
		sql = "SELECT * FROM question WHERE exam_id='" + examId + "'";

		// returning result of query
		return statement.executeQuery(sql);

	}// attendExam ends

	/**
	 * To save the result of the exam attended by student.
	 * 
	 * @return int
	 * @param examId
	 * @param studentId
	 * @param totalmarks
	 * @param obtainedMarks
	 * @param resultStatus
	 * @see attendExam
	 * @version 0.1
	 * @author Anupriya Gandhi
	 * 
	 */
	public int saveResult(String examId, String studentId, int totalmarks, int obtainedMarks, String resultStatus)
			throws SQLException, ClassNotFoundException {
		// sql query
		sql = "INSERT INTO result VALUES(?,?,?,?,?)";

		preparedStatement = DbConnection.getInstance().getConnection().prepareStatement(sql);

		// set values of query
		preparedStatement.setString(1, examId);
		preparedStatement.setString(2, studentId);
		preparedStatement.setInt(3, totalmarks);
		preparedStatement.setInt(4, obtainedMarks);
		preparedStatement.setString(5, resultStatus);
		// returning result of query
		return preparedStatement.executeUpdate();
	}// saveResult ends

}// class ends.
