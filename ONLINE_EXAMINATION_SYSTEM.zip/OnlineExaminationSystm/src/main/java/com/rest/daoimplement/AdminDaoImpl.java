/***********************************************************************

File Name		     :AdminDaoImpl.java
Principal Author	     :Amrutha v s
Subsystem Name               :Core Java Training
Module Name                  :
Date of First Release        :28-October-2020
Author                       :Amrutha v s
Description                  :Implementation of AdminDao


Change History

Version                     :0.1
Date(DD/MM/YYYY)            :28-October-2020
Modified by                 :Amrutha v s
Description of change       :Initial Version

***********************************************************************/
package com.rest.daoimplement;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.rest.dao.AdminDao;

import com.rest.util.DbConnection;

/**
 * Implementation ofAdminDao
 * 
 * @see AdminDaoImpl
 * @version 0.1
 * @author Amrutha v s
 * @since 28-October-2020
 */
public class AdminDaoImpl implements AdminDao {
	// Creating the reference variables.
	Statement statement = null;
	PreparedStatement preparedStatement = null;

	String sql = null;

	/**
	 * Method of viewInstitute
	 * 
	 * @see viewInstitute
	 * @return ResultSet
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 * @author Amrutha v s
	 */
	public ResultSet viewInstitute() throws SQLException, ClassNotFoundException {
		statement = DbConnection.getInstance().getConnection().createStatement();
		sql = "select * from institutes";
		return statement.executeQuery(sql);

	}// viewInstitute ends

	/**
	 * Method of deleteInstitute
	 * 
	 * @see deleteInstitute
	 * @param instituteId
	 * @return int
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 * @author Amrutha v s
	 */
	public int deleteInstituite(String instituteId) throws SQLException, ClassNotFoundException {
		preparedStatement = DbConnection.getInstance().getConnection()
				.prepareStatement("delete from students where student_institute_id =?");
		preparedStatement.setString(1, instituteId);
		preparedStatement.executeUpdate();
		preparedStatement = DbConnection.getInstance().getConnection()
				.prepareStatement("delete from institutes where institute_id =?");
		preparedStatement.setString(1, instituteId);

		return preparedStatement.executeUpdate();

	}// deleteInstitute ends
}// class ends
