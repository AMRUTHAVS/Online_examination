/***********************************************************************

File Name		     :InstituteService.java
Principal Author	     :Anand k j
Subsystem Name               :Core Java Training
Module Name                  :
Date of First Release        :28-October-2020
Author                       :Anand k j
Description                  :Interface for class of Institute Service


Change History

Version                     :0.1
Date(DD/MM/YYYY)            :28-October-2020
Modified by                 :Anand k j
Description of change       :Initial Version

 ***********************************************************************/
package com.rest.service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import com.rest.model.Question;

/**
 * Interface for class of Institute Service
 *
 * @see InstituteService
 * @version 0.1
 * @author Anand k j
 * 
 */
public interface InstituteService {
	/**
	 * method to add an institution
	 *
	 * @see addInstitute
	 * @param instName
	 * @param instEmail
	 * @param instAddress
	 * @param instPhone
	 * @param instPass
	 * @return integer value
	 * @version 0.1
	 * @author Sruthi Suresh
	 * 
	 */
	public int addInstitute(String instName, String instEmail, String instAddress, String instPhone, String instPass)
			throws ClassNotFoundException, SQLException;

	/**
	 * Method to add an exam
	 * 
	 * @param instituteId
	 * @param questionList
	 * @return int
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 * @version 0.1
	 * @author Anand k j
	 * 
	 * 
	 */
	public int addExam(String instituteId, List<Question> questionList) throws ClassNotFoundException, SQLException;

	/**
	 * Method to delete exam
	 * 
	 * @param examId
	 * @return int
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 * @version 0.1
	 * @author Anand k j
	 * 
	 */
	public int deleteExam(String examId) throws ClassNotFoundException, SQLException;

	/**
	 * Method to delete student
	 * 
	 * @param studentId
	 * @return int
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 * @version 0.1
	 * @author Anand k j
	 * 
	 */
	public int deleteStudent(String studentId) throws ClassNotFoundException, SQLException;

	/**
	 * Method to Show exam
	 * 
	 * @param instituteId
	 * @return resultset
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 * @version 0.1
	 * @author Anand k j
	 * 
	 */
	public ResultSet showExam(String instituteId) throws ClassNotFoundException, SQLException;

	/**
	 * Method to get student
	 * 
	 * @param studentId
	 * @return resultset
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 * @version 0.1
	 * @author Anand k j
	 * 
	 */
	public ResultSet getStudent(String studentId) throws ClassNotFoundException, SQLException;

	/**
	 * Method to show report
	 * 
	 * @param examId
	 * @return resultset
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 * @version 0.1
	 * @author Anand k j
	 * 
	 */
	public ResultSet showReport(String examId) throws ClassNotFoundException, SQLException;
}// Interface ends
