/***********************************************************************

File Name		      :InstituteController.java
Principal Author	      :Anand k j
Subsystem Name                :Core Java Training
Module Name                   :
Date of First Release         :28-October-2020
Author                        : Anand k j
Description                   : interface for service impl class


Change History

Version                     :0.1
Date(DD/MM/YYYY)            :28-October-2020
Modified by                 :Anand k j
Description of change       :Initial Version

 ***********************************************************************/
package com.rest.service;

/**
 * interface for serviceimpl class
 *
 * @see InstituteDetails
 * @version 0.1
 * @author Anand k j
 * @since 28-October-2020
 */
public interface InstituteDetails {
	/**
	 * method to add an institution
	 *
	 * @see addInstitute
	 * @param instName
	 * @param instEmail
	 * @param instAddress
	 * @param instPhone
	 * @param instPass
	 * @return integer value
	 * @version 0.1
	 * @author Anand k j
	 * @since 28-October-2020
	 */
	public int addInstitute(String instName, String instEmail, String instAddress, String instPhone, String instPass);
}
