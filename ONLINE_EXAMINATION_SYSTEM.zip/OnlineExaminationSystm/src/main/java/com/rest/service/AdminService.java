/***********************************************************************

File Name		      :AdminService.java
Principal Author	      :Amrutha v s
Subsystem Name                :Core Java Training
Module Name                   :
Date of First Release         :28-October-2020
Author                        :Amrutha v s
Description                   :Interface of AdminSevice


Change History

Version                     :0.1
Date(DD/MM/YYYY)            :28-October-2020
Modified by                 :Amrutha v s
Description of change       :Initial Version

***********************************************************************/
package com.rest.service;

import java.sql.SQLException;

/**
 * Interface of Admin Service
 * 
 * @return
 * @param
 * @see AdminService
 * @version 0.1
 * @author Amrutha v s
 * 
 */

public interface AdminService {
	/**
	 * Method for deleteInstitute
	 * 
	 * @author Amrutha v s
	 * @param instituteId
	 * @return integer value
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	public int deleteInstitute(String instituteId) throws ClassNotFoundException, SQLException;
}// Interface ends
