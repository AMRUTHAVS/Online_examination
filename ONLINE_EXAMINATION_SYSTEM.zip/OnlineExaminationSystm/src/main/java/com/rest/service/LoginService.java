/***********************************************************************

File Name		     :LoginService.java
Principal Author	     :Sruthi Suresh
Subsystem Name               :Core Java Training
Module Name                  :
Date of First Release        :28-October-2020
Author                       :Sruthi Suresh
Description                  :Interface for login class


Change History

Version                     :0.1
Date(DD/MM/YYYY)            :28-October-2020
Modified by                 :Sruthi Suresh
Description of change       :Initial Version

 ***********************************************************************/
package com.rest.service;

import java.sql.SQLException;

/**
 * Interface for login class
 *
 * @see LoginService
 * @version 0.1
 * @author Sruthi Suresh
 * @since 28-October-2020
 */
public interface LoginService {
	/**
	 * Method to userLogin
	 * 
	 * @see userLogin
	 * @param userEmail
	 * @param userPass
	 * @return string
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 * @author Sruthi Suresh
	 * 
	 */
	public String userLogin(String userEmail, String userPass) throws ClassNotFoundException, SQLException;
}// Interface ends
