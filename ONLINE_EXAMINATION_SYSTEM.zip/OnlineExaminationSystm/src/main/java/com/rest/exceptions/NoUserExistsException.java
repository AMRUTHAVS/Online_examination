/***********************************************************************

File Name		     :NoUserExistsException.java
Principal Author	     :Amrutha v s
Subsystem Name               :Core Java Training
Module Name                  :
Date of First Release        :28-October-2020
Author                       :Amrutha v s
Description                  :UserDefined Exception


Change History

Version                     :0.1
Date(DD/MM/YYYY)            :28-October-2020
Modified by                 :Amrutha v s
Description of change       :Initial Version

 ***********************************************************************/
package com.rest.exceptions;

/**
 * UserDefined Exception
 *
 * @see NoUserExistsException
 * @version 0.1
 * @author Amrutha v s
 * @since 28-October-2020
 */
public class NoUserExistsException extends Exception {

	private static final long serialVersionUID = 1L;

	public NoUserExistsException(String message) {
super(message);
	}
}// class ends