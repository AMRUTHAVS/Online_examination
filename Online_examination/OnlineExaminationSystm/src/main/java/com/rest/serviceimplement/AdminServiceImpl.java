/***********************************************************************
                         Altran Technologies Proprietary

This source code is the sole property of Altran Technologies. Any form of utilization
of this source code in whole or in part is  prohibited without  written consent from
Altran Technologies

File Name				      :AdminServiceImpl.java
Principal Author			  :Ayushi Srivastava
Subsystem Name                :Core Java Training
Module Name                   :
Date of First Release         :28-October-2020
Author                        :Ayushi Srivastava
Description                   :Implementation class of Admin Service


Change History

Version                     :0.1
Date(DD/MM/YYYY)            :28-October-2020
Modified by                 :Ayushi Srivastava
Description of change       :Initial Version

***********************************************************************/
package com.rest.serviceimplement;

import java.sql.SQLException;
import com.rest.dao.AdminDao;
import com.rest.daoimplement.AdminDaoImpl;
import com.rest.service.AdminService;

/**
 * Implementation class of Admin service
 * 
 * @return
 * @param
 * @see AdminServiceImpl
 * @version 0.1
 * @author Ayushi Srivastava
 * 
 */
public class AdminServiceImpl implements AdminService {
	// Creating object of AdminDao using upcasting
	AdminDao adminDao = new AdminDaoImpl();

	/**
	 * Method For calling deleteInstitute function of the dao layer
	 * 
	 * @return int
	 * @param instituteId
	 * @see deleteInstitute
	 * @version 0.1
	 * @author Ayushi Srivastava
	 * 
	 */
	public int deleteInstitute(String instituteId) throws ClassNotFoundException, SQLException {
		// Calling the deleteInstitute function from dao layer
		return adminDao.deleteInstituite(instituteId);
	}
}// class Ends
