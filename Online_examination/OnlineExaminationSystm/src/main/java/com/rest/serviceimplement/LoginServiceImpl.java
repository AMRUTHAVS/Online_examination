/***********************************************************************
                         Altran Technologies Proprietary

This source code is the sole property of Altran Technologies. Any form of utilization
of this source code in whole or in part is  prohibited without  written consent from
Altran Technologies

File Name				     :LoginServiceImpl.java
Principal Author			 :Sruthi Suresh
Subsystem Name               :Core Java Training
Module Name                  :
Date of First Release        :28-October-2020
Author                       :Sruthi Suresh
Description                  :Implementation of loginService class


Change History

Version                     :0.1
Date(DD/MM/YYYY)            :28-October-2020
Modified by                 :Sruthi Suresh
Description of change       :Initial Version

 ***********************************************************************/
package com.rest.serviceimplement;

import java.sql.SQLException;

import com.rest.daoimplement.LoginDaoImpl;
import com.rest.service.LoginService;

/**
 * Implementation of loginService class
 *
 * @see LoginServiceImpl
 * @version 0.1
 * @author Sruthi Suresh
 * @since 28-October-2020
 */
public class LoginServiceImpl implements LoginService {
	// Creating object of LoginDaoImpl
	LoginDaoImpl loginDao = new LoginDaoImpl();

	/**
	 * Method to userLogin
	 * 
	 * @see userLogin
	 * @param userEmail
	 * @param userPass
	 * @return string
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 * @author Sruthi Suresh
	 * 
	 */
	public String userLogin(String userEmail, String userPass) throws ClassNotFoundException, SQLException {
		// Calling userLogin using dao object
		return loginDao.userLogin(userEmail, userPass);
	}
}// class ends
