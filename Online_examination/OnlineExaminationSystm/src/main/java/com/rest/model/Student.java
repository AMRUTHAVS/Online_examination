/***********************************************************************
                         Altran Technologies Proprietary

This source code is the sole property of Altran Technologies. Any form of utilization
of this source code in whole or in part is  prohibited without  written consent from
Altran Technologies

File Name				     :Student.java
Principal Author			 :Ayushi Srivastava
Subsystem Name               :Core Java Training
Module Name                  :
Date of First Release        :28-October-2020
Author                       :Ayushi Srivastava
Description                  :Pojo class of Students


Change History

Version                     :0.1
Date(DD/MM/YYYY)            :28-October-2020
Modified by                 :Ayushi Srivastava
Description of change       :Initial Version

***********************************************************************/
package com.rest.model;

/**
 * To setup getters and setters
 * 
 * @see Student
 * @version 0.1
 * @author Ayushi Srivastava
 * 
 */
public class Student {
	// Instance Variables
	private String studName;
	private String studInstitution;
	private String studEmail;
	private String studPass;
	private String studMob;
	private String studClass;

	// Generating the getters and setters.

	/**
	 * @see getStudName
	 * @version 0.1
	 * @author Ayushi Srivastava
	 * 
	 * @return the studName
	 */
	public String getStudName() {
		return studName;
	}

	/**
	 * the studName to set
	 * 
	 * @see setStudName
	 * @version 0.1
	 * @author Ayushi Srivastava
	 * 
	 * @param studName
	 */
	public void setStudName(String studName) {
		this.studName = studName;
	}

	/**
	 * @see getStudInsId
	 * @version 0.1
	 * @author Ayushi Srivastava
	 * 
	 * @return the studInsId
	 */
	public String getStudInstitution() {
		return studInstitution;
	}

	/**
	 * the studInsId to set
	 * 
	 * @see setStudInsId
	 * @version 0.1
	 * @author Ayushi Srivastava
	 * 
	 * @param studInsId
	 */
	public void setStudInstitution(String studInstitution) {
		this.studInstitution = studInstitution;
	}

	/**
	 * @see getStudEmail
	 * @version 0.1
	 * @author Ayushi Srivastava
	 * 
	 * @return the studEmail
	 */
	public String getStudEmail() {
		return studEmail;
	}

	/**
	 * the studEmail to set
	 * 
	 * @see setStudEmail
	 * @version 0.1
	 * @author Ayushi Srivastava
	 * 
	 * @param studEmail
	 */
	public void setStudEmail(String studEmail) {
		this.studEmail = studEmail;
	}

	/**
	 * @see getStudPass
	 * @version 0.1
	 * @author Ayushi Srivastava
	 * 
	 * @return the studPass
	 */
	public String getStudPass() {
		return studPass;
	}

	/**
	 * the studPass to set
	 * 
	 * @see setStudPass
	 * @version 0.1
	 * @author Ayushi Srivastava
	 * 
	 * @param studPass
	 */
	public void setStudPass(String studPass) {
		this.studPass = studPass;
	}

	/**
	 * @see getStudMob
	 * @version 0.1
	 * @author Ayushi Srivastava
	 * 
	 * @return the studMob
	 */
	public String getStudMob() {
		return studMob;
	}

	/**
	 * the studMob to set
	 * 
	 * @see setStudMob
	 * @version 0.1
	 * @author Ayushi Srivastava
	 * 
	 * @param studMob
	 */
	public void setStudMob(String studMob) {
		this.studMob = studMob;
	}

	/**
	 * @see getStudClass
	 * @version 0.1
	 * @author Ayushi Srivastava
	 * 
	 * @return the studMob
	 */
	public String getStudClass() {
		return studClass;
	}

	/**
	 * the studMob to set
	 * 
	 * @see setStudMob
	 * @version 0.1
	 * @author Ayushi Srivastava
	 * 
	 * @param studMob
	 */
	public void setStudClass(String studClass) {
		this.studClass = studClass;
	}
} // class ends