/***********************************************************************
                         Altran Technologies Proprietary

This source code is the sole property of Altran Technologies. Any form of utilization
of this source code in whole or in part is  prohibited without  written consent from
Altran Technologies

File Name				     :Question.java
Principal Author			 :Piyush Kumar
Subsystem Name               :Core Java Training
Module Name                  :
Date of First Release        :28-October-2020
Author                       :Piyush Kumar
Description                  :Pojo class of question


Change History

Version                     :0.1
Date(DD/MM/YYYY)            :28-October-2020
Modified by                 :Piyush Kumar
Description of change       :Initial Version

***********************************************************************/
package com.rest.model;

/**
 * To setup getters and setters
 * 
 * @see Question
 * @version 0.1
 * @author Piyush Kumar
 * 
 */

public class Question {
	// Instance Variables
	private String examName;
	private String examBranch;
	private String examDate;
	private String questionStatement;
	private String optionOne;
	private String optionTwo;
	private String optionThree;
	private String optionFour;
	private String correctAnswer;

	/**
	 * Getter method to get exam name
	 *
	 * @see getExamName
	 * @return examName
	 * @version 0.1
	 * @author Piyush Kumar
	 * 
	 */
	public String getExamName() {
		return examName;
	}

	/**
	 * Setter method to set exam name
	 *
	 * @see setExamName
	 * @param examName
	 * @version 0.1
	 * @author Piyush Kumar
	 * 
	 */
	public void setExamName(String examName) {
		this.examName = examName;
	}

	/**
	 * Getter method to get exam branch
	 *
	 * @see getExamBranch
	 * @return examBranch
	 * @version 0.1
	 * @author Piyush Kumar
	 * 
	 */
	public String getExamBranch() {
		return examBranch;
	}

	/**
	 * Setter method to set exam branch
	 *
	 * @see setExambranch
	 * @param examBranch
	 * @version 0.1
	 * @author Piyush Kumar
	 * 
	 */
	public void setExamBranch(String examBranch) {
		this.examBranch = examBranch;
	}

	/**
	 * Getter method to get exam date
	 *
	 * @see getExamDate
	 * @return examDate
	 * @version 0.1
	 * @author Piyush Kumar
	 * 
	 */
	public String getExamDate() {
		return examDate;
	}

	/**
	 * Setter method to set exam date
	 *
	 * @see setExamDate
	 * @param examDate
	 * @version 0.1
	 * @author Piyush Kumar
	 * 
	 */
	public void setExamDate(String examDate) {
		this.examDate = examDate;
	}

	/**
	 * Getter method to get question
	 *
	 * @see getQuestion
	 * @return questionstatement
	 * @version 0.1
	 * @author Piyush Kumar
	 * 
	 */
	public String getQuestion() {
		return questionStatement;
	}

	/**
	 * Setter method to set question
	 *
	 * @see setQuestion
	 * @param questionstatement
	 * @version 0.1
	 * @author Piyush Kumar
	 * 
	 */
	public void setQuestion(String question) {
		this.questionStatement = question;
	}

	/**
	 * Getter method to get option one
	 *
	 * @see getOptionOne
	 * @return optionone
	 * @version 0.1
	 * @author Piyush Kumar
	 * 
	 */
	public String getOptionOne() {
		return optionOne;
	}

	/**
	 * Setter method to set option one
	 *
	 * @see set OptionOne
	 * @param Optionone
	 * @version 0.1
	 * @author Piyush Kumar
	 * 
	 */
	public void setOptionOne(String optionOne) {
		this.optionOne = optionOne;
	}

	/**
	 * Getter method to get option two
	 *
	 * @see getOptionTwo
	 * @return optiontwo
	 * @version 0.1
	 * @author Piyush Kumar
	 * 
	 */
	public String getOptionTwo() {
		return optionTwo;
	}

	/**
	 * Setter method to set option two
	 *
	 * @see set OptionTwo
	 * @param Optiontwo
	 * @version 0.1
	 * @author Piyush Kumar
	 * 
	 */
	public void setOptionTwo(String optionTwo) {
		this.optionTwo = optionTwo;
	}

	/**
	 * Getter method to get option three
	 *
	 * @see getOptionThree
	 * @return optionthree
	 * @version 0.1
	 * @author Piyush Kumar
	 * 
	 */
	public String getOptionThree() {
		return optionThree;
	}

	/**
	 * Setter method to set option three
	 *
	 * @see set OptionThree
	 * @param Optionthree
	 * @version 0.1
	 * @author Piyush Kumar
	 * 
	 */
	public void setOptionThree(String optionThree) {
		this.optionThree = optionThree;
	}

	/**
	 * Getter method to get option four
	 *
	 * @see getOptionFour
	 * @return optionfour
	 * @version 0.1
	 * @author Piyush Kumar
	 * 
	 */
	public String getOptionFour() {
		return optionFour;
	}

	/**
	 * Setter method to set option four
	 *
	 * @see set OptionFour
	 * @param Optionfour
	 * @version 0.1
	 * @author Piyush Kumar
	 * 
	 */
	public void setOptionFour(String optionFour) {
		this.optionFour = optionFour;
	}

	/**
	 * Getter method to get correct answer
	 *
	 * @see getCorrectAnswer
	 * @return correctanswer
	 * @version 0.1
	 * @author Piyush Kumar
	 * 
	 */
	public String getCorrectAnswer() {
		return correctAnswer;
	}

	/**
	 * Setter method to set correct answer
	 *
	 * @see set CorrectAnswer
	 * @param Correctanswer
	 * @version 0.1
	 * @author Piyush Kumar
	 * 
	 */
	public void setCorrectAnswer(String correctAnswer) {
		this.correctAnswer = correctAnswer;
	}

}// class ends