/***********************************************************************
                         Altran Technologies Proprietary

This source code is the sole property of Altran Technologies. Any form of utilization
of this source code in whole or in part is  prohibited without  written consent from
Altran Technologies

File Name				     :InstituteDaoImpl.java
Principal Author			 :Anand k j
Subsystem Name               :Core Java Training
Module Name                  :
Date of First Release        :28-October-2020
Author                       : Anand k j
Description                  :Implementation of InstituteDao


Change History

Version                     :0.1
Date(DD/MM/YYYY)            :28-October-2020
Modified by                 :Anand k j
Description of change       :Initial Version

 ***********************************************************************/
package com.rest.daoimplement;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import com.rest.dao.InstituteDao;

import com.rest.model.Institute;
import com.rest.model.Question;
import com.rest.util.DbConnection;

/**
 * Implementation of InstituteDao
 *
 * @see InstituteDaoImpl
 * @version 0.1
 * @author Anand k j
 * @since 28-October-2020
 */
public class InstituteDaoImpl implements InstituteDao {
	// Creating the reference variables.
	PreparedStatement ps;
	Statement st = null;
	String query;
	ResultSet rs;

	/**
	 * method to add an institution
	 *
	 * @see addInstitute
	 * @param institute
	 * @return integer value
	 * @version 0.1
	 * @author Anand k j
	 * 
	 */
	public int addInstitute(Institute institute) throws ClassNotFoundException, SQLException {
		// Displaying the details of the institute using sql command
		query = "select * from institutes where institute_email=?";
		// Calling the database connection function
		ps = DbConnection.getInstance().getConnection().prepareStatement(query);
		ps.setString(1, institute.getInstEmail());
		rs = ps.executeQuery();
		// if already existing user then return 0
		if (rs.next())
			return 0;
		// not existing user add to institutes table
		query = "insert into institutes(institute_name,institute_email,institute_password,institute_mob,institute_address) values(?,?,?,?,?)";
		ps = DbConnection.getInstance().getConnection().prepareStatement(query);
		ps.setString(1, institute.getInstName());
		ps.setString(2, institute.getInstEmail());
		ps.setString(3, institute.getInstPass());
		ps.setString(4, institute.getInstPhone());
		ps.setString(5, institute.getInstAddress());
		return ps.executeUpdate();

	}// addInstitute ends

	/**
	 * Method to getInstitute
	 * 
	 * @see getInstitute
	 * @param instEmail
	 * @return ResultSet
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 * @author Anand k j
	 */
	public ResultSet getInstitute(String instEmail) throws SQLException, ClassNotFoundException {
		// retriving institute details by passing particular institute id
		query = "select * from institutes where institute_email=?";
		ps = DbConnection.getInstance().getConnection().prepareStatement(query);
		ps.setString(1, instEmail);
		rs = ps.executeQuery();
		rs.next();
		return rs;
	}// getInstitute ends

	/**
	 * Method to addExam
	 * 
	 * @see addExam
	 * @param instituteId
	 * @param questionList
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 * @author Anand k j
	 */
	public int addExam(String instituteId, List<Question> questionList) throws ClassNotFoundException, SQLException {
		// adding exam details to exam table
		Question question = questionList.get(0);
		query = "insert into exam(exam_name,exam_date,institute_id,branch) values(?,?,?,?)";
		ps = DbConnection.getInstance().getConnection().prepareStatement(query);
		ps.setString(1, question.getExamName());
		ps.setString(2, question.getExamDate());
		ps.setString(3, instituteId);
		ps.setString(4, question.getExamBranch());
		ps.executeUpdate();
		st = DbConnection.getInstance().getConnection().createStatement();
		query = "select last_insert_id()";
		rs = st.executeQuery(query);
		rs.next();
		// adding each questions of particular exam to question table
		for (Question eachQuestion : questionList) {

			query = "insert into question(exam_id,question,option_one,option_two,option_three,option_four,correct_option) values(?,?,?,?,?,?,?)";
			ps = DbConnection.getInstance().getConnection().prepareStatement(query);
			ps.setString(1, rs.getString(1));
			ps.setString(2, eachQuestion.getQuestion());
			ps.setString(3, eachQuestion.getOptionOne());
			ps.setString(4, eachQuestion.getOptionTwo());
			ps.setString(5, eachQuestion.getOptionThree());
			ps.setString(6, eachQuestion.getOptionFour());
			ps.setString(7, eachQuestion.getCorrectAnswer());
			ps.executeUpdate();
		}
		return 1;
	}// addExam ends

	/**
	 * Method to deleteExams
	 * 
	 * @see deleteExams
	 * @param examId
	 * @return int
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 * @author Anand k j
	 */
	public int deleteExams(String examId) throws ClassNotFoundException, SQLException {
		// delete exam with particular id
		ps = DbConnection.getInstance().getConnection().prepareStatement("delete from question where exam_id =?");
		ps.setString(1, examId);
		ps.executeUpdate();
		ps = DbConnection.getInstance().getConnection().prepareStatement("delete from exam where exam_id =?");
		ps.setString(1, examId);
		return ps.executeUpdate();

	}// deleteExams ends

	/**
	 * Method to viewExam
	 * 
	 * @see viewExam
	 * @param instituteId
	 * @return Resultset
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 * @author Anand k j
	 */
	public ResultSet viewExam(String instituteId) throws SQLException, ClassNotFoundException {
		// to return exams associated with particular institute
		st = DbConnection.getInstance().getConnection().createStatement();
		query = "select * from exam where institute_id = '" + instituteId + "'";
		return st.executeQuery(query);

	}// viewExam ends

	/**
	 * Method to viewStudent
	 * 
	 * @see viewStudent
	 * @param instituteId
	 * @param studentBranch
	 * @return ResultSet
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 * @author Anand k j
	 */
	public ResultSet viewStudent(String instituteId, String studentBranch) throws SQLException, ClassNotFoundException {
		// to view the details of student in each particular class
		st = DbConnection.getInstance().getConnection().createStatement();
		query = "select * from students where student_branch = '" + studentBranch + "' AND student_institute_id = '"
				+ instituteId + "'";
		return st.executeQuery(query);

	}// viewStudents

	/**
	 * Method to deleteStudent
	 * 
	 * @see deleteStudent
	 * @param examId
	 * @return int
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 * @author Anand k j
	 */
	public int deleteStudent(String studentId) throws ClassNotFoundException, SQLException {
		// deleting student with particular student id
		ps = DbConnection.getInstance().getConnection().prepareStatement("delete from students where student_id =?");
		ps.setString(1, studentId);
		return ps.executeUpdate();
	}// deleteStudents ends

	/**
	 * Method to showExam
	 * 
	 * @see showExam
	 * @param instituteId
	 * @return resultset
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 * @author Anand k j
	 */
	public ResultSet showExam(String instituteId) throws ClassNotFoundException, SQLException {
		// setting query which return the exams to particlar student on after current
		// date
		long millis = System.currentTimeMillis();
		Date date = new Date(millis);
		query = "select * from exam where institute_id=? and exam_date <= '" + date + "'";
		ps = DbConnection.getInstance().getConnection().prepareStatement(query);
		ps.setString(1, instituteId);

		return ps.executeQuery();

	}// showExam ends

	/**
	 * Method to showReport
	 * 
	 * @see showReport
	 * @param examId
	 * @return ResultSet
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 * @author Anand k j
	 */

	public ResultSet showReport(String examId) throws ClassNotFoundException, SQLException {
		// prepraring query to get result of particular exam
		query = "select * from result where exam_id=?";
		ps = DbConnection.getInstance().getConnection().prepareStatement(query);
		ps.setString(1, examId);

		return ps.executeQuery();

	}// showReport ends

	/**
	 * Method to getStudent
	 * 
	 * @see getStudent
	 * @param studentId
	 * @return Resultset
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 * @author Anand k j
	 */
	public ResultSet getStudent(String studentId) throws ClassNotFoundException, SQLException {
		// setting query to get student details with particular student id
		query = "select * from students where student_id=?";
		ps = DbConnection.getInstance().getConnection().prepareStatement(query);
		ps.setString(1, studentId);

		return ps.executeQuery();

	}// getStudents ends

}// class ends