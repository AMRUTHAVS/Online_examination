/***********************************************************************
                         Altran Technologies Proprietary

This source code is the sole property of Altran Technologies. Any form of utilization
of this source code in whole or in part is  prohibited without  written consent from
Altran Technologies

File Name				     :InstituteDao.java
Principal Author			 :Anand k j
Subsystem Name               :Core Java Training
Module Name                  :
Date of First Release        :28-October-2020
Author                       : Anand k j
Description                  :Interface of InstituteDao


Change History

Version                     :0.1
Date(DD/MM/YYYY)            :28-October-2020
Modified by                 :Anand k j
Description of change       :Initial Version

 ***********************************************************************/
package com.rest.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import com.rest.model.Institute;
import com.rest.model.Question;

	/**
	 * Interface for daoimpl class.
	 *
	 * @see InstituteDao
	 * @version 0.1
	 * @author Anand k j
	 
	 */
	public interface InstituteDao 
	{
	/**
	 * method to add an institution
	 *
	 * @see addInstitute
	 * @param institute
	 * @return integer value
	 * @version 0.1
	 * @author Sruthi Suresh
	 
	 */
	public int addInstitute(Institute institute) throws ClassNotFoundException, SQLException;
	
	/**
	 * Method to addExam
	 * 
	 * @see addExam
	 * @param instituteId
	 * @param questionList
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 * @author Anand k j
	 */
	public int addExam(String instituteId,List<Question> questionList)throws ClassNotFoundException, SQLException;
	
	/**
	 * Method to getInstitute
	 * 
	 * @see getInstitute
	 * @param instEmail
	 * @return ResultSet
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 * @author Anand k j
	 */
	public ResultSet getInstitute(String instEmail) throws SQLException, ClassNotFoundException;
	
	/**
	 * Method to deleteExams
	 * 
	 * @see deleteExams
	 * @param examId
	 * @return int
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 * @author Anand k j
	 */
	public int deleteExams(String examId) throws ClassNotFoundException, SQLException;
	
	/**
	 * Method to viewExam
	 * 
	 * @see viewExam
	 * @param instituteId
	 * @return Resultset
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 * @author Anand k j
	 */
	public ResultSet viewExam(String instituteId) throws SQLException, ClassNotFoundException;
	
	/**
	 * Method to viewStudent
	 * 
	 * @see viewStudent
	 * @param instituteId
	 * @param studentBranch
	 * @return ResultSet
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 * @author Anand k j
	 */
   public ResultSet viewStudent(String instituteId, String studentBranch) throws SQLException, ClassNotFoundException;
	
   /**
    * Method to deleteStudent
    * 
    * @see deleteStudent
    * @param examId
    * @return int
    * @throws ClassNotFoundException
    * @throws SQLException
    * @author Anand k j
    */
   public int deleteStudent(String examId) throws ClassNotFoundException, SQLException;
   
   /**
    * Method to showExam
    * 
    * @see showExam
    * @param instituteId
    * @return resultset
    * @throws ClassNotFoundException
    * @throws SQLException
    * @author Anand k j
    */
   public ResultSet showExam(String instituteId)throws ClassNotFoundException, SQLException;
   
   /**
    * Method to showReport
    * 
    * @see showReport
    * @param examId
    * @return ResultSet
    * @throws ClassNotFoundException
    * @throws SQLException
    * @author Anand k j
    */
   public ResultSet showReport(String examId)throws ClassNotFoundException, SQLException;
   
   /**
    * Method to getStudent
    * 
    * @see getStudent
    * @param studentId
    * @return Resultset
    * @throws ClassNotFoundException
    * @throws SQLException
    * @author Anand k j
    */
   public ResultSet getStudent(String studentId)throws ClassNotFoundException, SQLException;
}// interface ends

