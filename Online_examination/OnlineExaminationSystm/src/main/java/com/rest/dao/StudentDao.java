/***********************************************************************
                         Altran Technologies Proprietary

This source code is the sole property of Altran Technologies. Any form of utilization
of this source code in whole or in part is  prohibited without  written consent from
Altran Technologies

File Name				   :Program1.java
Principal Author			   :Anupriya Gandhi
Subsystem Name                :Core Java Training
Module Name                   :
Date of First Release         :28-October-2020
Author                           : Anupriya Gandhi
Description                :Interface for performing database-related logic for the Student module


Change History

Version                      :0.1
Date(DD/MM/YYYY)            :28-October-2020
Modified by                 :Anupriya Gandhi
Description of change       :Initial Version

***********************************************************************/
package com.rest.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.rest.model.Student;

/**
 * Interface for performing database-related logic for the Student module
 * 
 * @return
 * @param
 * @see Program1
 * @version 0.1
 * @author Anupriya Gandhi
 * @since 28-October-2020
 */
public interface StudentDao {

	/**
	 * To register student.
	 * 
	 * @return int
	 * @param student
	 * @see registerStudent
	 * @version 0.1
	 * @author Sruthi Suresh
	 * 
	 */
	public int registerStudent(Student student) throws ClassNotFoundException, SQLException;

	/**
	 * To get student.
	 * 
	 * @return ResultSet
	 * @param studEmail
	 * @see getStudent
	 * @version 0.1
	 * @author Anupriya Gandhi
	 * 
	 */
	public ResultSet getStudent(String studEmail) throws SQLException, ClassNotFoundException;

	/**
	 * To get the result of the student.
	 * 
	 * @return ResultSet
	 * @param studentId
	 * @see getResult
	 * @version 0.1
	 * @author Anupriya Gandhi
	 * 
	 */
	public ResultSet getResult(String studentId) throws ClassNotFoundException, SQLException;

	/**
	 * To view the report of the student.
	 * 
	 * @return ResultSet
	 * @param examId
	 * @see viewReport
	 * @version 0.1
	 * @author Anupriya Gandhi
	 * 
	 */
	public ResultSet viewReport(String examId) throws ClassNotFoundException, SQLException;

	/**
	 * To view the schedule.
	 * 
	 * @return ResultSet
	 * @param institudeId,studentBranch
	 * @see viewSchedule
	 * @version 0.1
	 * @author Anupriya Gandhi
	 * 
	 */
	public ResultSet viewSchedule(String institudeId, String studentBranch) throws SQLException, ClassNotFoundException;

	/**
	 * To view the report of the student.
	 * 
	 * @return ResultSet
	 * @param instituteId,
	 *            branch
	 * @see examToAttend
	 * @version 0.1
	 * @author Anupriya Gandhi
	 * 
	 */
	public ResultSet examToAttend(String instituteId, String branch) throws SQLException, ClassNotFoundException;

	/**
	 * To attend the exam by student.
	 * 
	 * @return ResultSet
	 * @param examId
	 * @see attendExam
	 * @version 0.1
	 * @author Anupriya Gandhi
	 * 
	 */
	public ResultSet attendExam(String examId) throws SQLException, ClassNotFoundException;

	/**
	 * To save the result of the exam attended by student.
	 * 
	 * @return int
	 * @param examId
	 * @param studentId
	 * @param totalmarks
	 * @param obtainedMarks
	 * @param resultStatus
	 * @see attendExam
	 * @version 0.1
	 * @author Anupriya Gandhi
	 * 
	 */
	public int saveResult(String examId, String studentId, int totalmarks, int obtainedMarks, String resultStatus)
			throws SQLException, ClassNotFoundException;
}// interface ends
