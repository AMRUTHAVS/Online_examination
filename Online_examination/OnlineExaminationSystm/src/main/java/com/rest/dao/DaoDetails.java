/***********************************************************************
                         Altran Technologies Proprietary

This source code is the sole property of Altran Technologies. Any form of utilization
of this source code in whole or in part is  prohibited without  written consent from
Altran Technologies

File Name				   :InstituteController.java
Principal Author			   :Anand k j
Subsystem Name                :Core Java Training
Module Name                   :
Date of First Release         :28-October-2020
Author                           : Anand k j
Description                : interface for daoimpl class.


Change History

Version                      :0.1
Date(DD/MM/YYYY)            :28-October-2020
Modified by                 :Anand k j
Description of change       :Initial Version

 ***********************************************************************/
package com.rest.dao;

import com.rest.model.Institute;

/**
 * interface for daoimpl class.
 *
 * @see DaoDetails
 * @version 0.1
 * @author Anand k j
 * @since 28-October-2020
 */
public interface DaoDetails {
	/**
	 * method to add an institution
	 *
	 * @see addInstitute
	 * @param institute
	 *            : Institute object
	 * @return integer value
	 * @version 0.1
	 * @author Anand k j
	 * @since 28-October-2020
	 */
	public int addInstitute(Institute institute);
}
