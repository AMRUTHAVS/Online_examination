/***********************************************************************
                         Altran Technologies Proprietary

This source code is the sole property of Altran Technologies. Any form of utilization
of this source code in whole or in part is  prohibited without  written consent from
Altran Technologies

File Name				     :AdminDao.java
Principal Author			 :Ayushi Srivastava
Subsystem Name               :Core Java Training
Module Name                  :
Date of First Release        :28-October-2020
Author                       :Ayushi Srivastava
Description                  :Interface of AdminDao


Change History

Version                     :0.1
Date(DD/MM/YYYY)            :28-October-2020
Modified by                 :Ayushi Srivastava
Description of change       :Initial Version

***********************************************************************/
package com.rest.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Interface of Admin
 * 
 * @see AdminDao
 * @version 0.1
 * @author Ayushi Srivastava
 * 
 */
public interface AdminDao {
	/**
	 * Method of viewInstitute
	 * 
	 * @return ResultSet
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 * @author Ayushi Srivastava
	 */
	public ResultSet viewInstitute() throws SQLException, ClassNotFoundException;

	/**
	 * Method of deleteInstitute
	 * 
	 * @param instituteId
	 * @return int
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 * @author Ayushi Srivastava
	 */
	public int deleteInstituite(String instituteId) throws SQLException, ClassNotFoundException;
}// interface ends