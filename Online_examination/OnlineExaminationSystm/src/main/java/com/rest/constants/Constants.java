/***********************************************************************
                         Altran Technologies Proprietary

This source code is the sole property of Altran Technologies. Any form of utilization
of this source code in whole or in part is  prohibited without  written consent from
Altran Technologies

File Name				   :Constants.java
Principal Author			   :Ayushi Srivastava
Subsystem Name                :Core Java Training
Module Name                   :
Date of First Release         :28-October-2020
Author                           : Ayushi Srivastava
Description                :Class that contains constant values.


Change History

Version                      :0.1
Date(DD/MM/YYYY)            :28-October-2020
Modified by                 :Ayushi Srivastava
Description of change       :Initial Version

 ***********************************************************************/
package com.rest.constants;

/**
 * Class that contains constant values.
 * 
 * @return
 * @param
 * @see Constants
 * @version 0.1
 * @author Ayushi Srivastava
 */
public class Constants {
	private Constants()
	{
	
	}
	// defining constants
		public static final String URL = "jdbc:mysql://localhost:3306/onlineexaminationsystem";
		public static final String USER = "root";
		public static final String PASS = "root";
}// class ends.
