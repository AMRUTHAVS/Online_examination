/***********************************************************************
                         Altran Technologies Proprietary

This source code is the sole property of Altran Technologies. Any form of utilization
of this source code in whole or in part is  prohibited without  written consent from
Altran Technologies

File Name				     :LoginController.java
Principal Author			 :Sruthi Suresh
Subsystem Name               :Core Java Training
Module Name                  :
Date of First Release        :28-October-2020
Author                       :Sruthi Suresh
Description                  :To control the rest api's of Login


Change History

Version                     :0.1
Date(DD/MM/YYYY)            :28-October-2020
Modified by                 :Sruthi Suresh
Description of change       :Initial Version

 ***********************************************************************/
package com.rest.controllers;

import java.net.URI;
import java.net.URISyntaxException;
import java.sql.SQLException;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;

import com.rest.exceptions.NoUserExistsException;
import com.rest.service.LoginService;
import com.rest.serviceimplement.LoginServiceImpl;

/**
 * To control the rest api's
 *
 * @see LoginController
 * @version 0.1
 * @author Sruthi Suresh
 */
@Path("/login")
public class LoginController {
	// creating object of LoginServiceImpl using up casting
	LoginService loginService = new LoginServiceImpl();
	// creating object of logger class
	Logger logger = Logger.getAnonymousLogger();
	// declaring uri variable
	URI uri = null;

	/**
	 * To user login
	 *
	 * @see userLogin
	 * @version 0.1
	 * @return Response
	 * @param name
	 *            : user Email
	 * @param password
	 *            : user password
	 * @author Sruthi Suresh
	 */

	@Context
	static HttpServletRequest request;

	@POST
	public Response userLogin(@FormParam("name") String userEmail, @FormParam("password") String userPass)
			throws ClassNotFoundException, SQLException, URISyntaxException {
		// creating session
		HttpSession session = request.getSession();

		String path;

		// checking the type of user and set the uri whether inputs are correct
		try {
			if (userEmail.equalsIgnoreCase("admin") && userPass.equalsIgnoreCase("Admin@123")) {
				path = "http://localhost:8080/OnlineExaminationSystm/adminService.jsp";
				uri = new URI(path);
				session.setAttribute("user", "ADMIN");
			} else {
				String userType = loginService.userLogin(userEmail, userPass);

				if (userType.equalsIgnoreCase("institute")) {
					path = "http://localhost:8080/OnlineExaminationSystm/instituteService.jsp";
					uri = new URI(path);
					session.setAttribute("user", userEmail);
				} else if (userType.equalsIgnoreCase("student")) {
					path = "http://localhost:8080/OnlineExaminationSystm/studentService.jsp";
					uri = new URI(path);
					session.setAttribute("user", userEmail);
				} else {
					// throws user defined exceptions
					throw new NoUserExistsException("exception thrown");
				}
			}
		} catch (URISyntaxException e) {
			logger.info(e.getMessage());
		} catch (NoUserExistsException e) {
			path = "http://localhost:8080/OnlineExaminationSystm/login.jsp?msg=nouser";
			uri = new URI(path);
		} // try-catch ends

		return Response.seeOther(uri).build();

	}// userLogin ends

}// class ends
