/***********************************************************************
                         Altran Technologies Proprietary

This source code is the sole property of Altran Technologies. Any form of utilization
of this source code in whole or in part is  prohibited without  written consent from
Altran Technologies

File Name				     :InstituteController.java
Principal Author			 :Anand k j
Subsystem Name               :Core Java Training
Module Name                  :
Date of First Release        :28-October-2020
Author                       : Anand k j
Description                  :To control the rest api's of Institute.


Change History

Version                      :0.1
Date(DD/MM/YYYY)            :28-October-2020
Modified by                 :Anand k j
Description of change       :Initial Version

 ***********************************************************************/
package com.rest.controllers;

import java.net.URI;
import java.net.URISyntaxException;
import java.sql.SQLException;
import java.util.logging.Logger;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.rest.exceptions.UserAlreadyExistsException;
import com.rest.service.InstituteService;
import com.rest.serviceimplement.InstituteServiceImpl;

/**
 * To control the rest api's.
 *
 * @see InstituteController
 * @version 0.1
 * @author Anand k j
 */
@Path("/institute")
public class InstituteController {
	// creating object of InstituteServiceImpl object using upper casting
	InstituteService instituteService = new InstituteServiceImpl();
	// creating object of logger class
	Logger logger = Logger.getAnonymousLogger();
	// declaring uri variable
	URI uri = null;

	/**
	 * To hit the rest api for adding institutes
	 *
	 * @see addInstitute
	 * @param name
	 *            : institution name
	 * @param email
	 *            : institution email
	 * @param address
	 *            : institution address
	 * @param phone
	 *            : institution phone number
	 * @param pass
	 *            : institution password
	 * @return response
	 * @version 0.1
	 * @author Sruthi Suresh
	 * @throws UserAlreadyExists
	 */
	@POST
	@Path("/add")
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_JSON })
	public Response addInstitue(@FormParam("name") String instName, @FormParam("phone") String instPhone,
			@FormParam("address") String instAddress, @FormParam("email") String instEmail,
			@FormParam("password") String instPass) throws ClassNotFoundException, SQLException, URISyntaxException {
		int result = 0;
		String message = null;

		// setting the uri according to the result
		if (instName != null && instPhone != null && instAddress != null && instEmail != null && instPass != null) {
			// calling addInstitute method
			result = instituteService.addInstitute(instName, instEmail, instAddress, instPhone, instPass);
		} // if ends

		try {

			if (result == 1) {
				message = "success";

			} else {
				// throws user defined exceptions
				throw new UserAlreadyExistsException("exception thrown");

			}
		} catch (UserAlreadyExistsException e) {
			message = "failed";
		} // try-catch ends
		String path = "http://localhost:8080/OnlineExaminationSystm/login.jsp?msg=" + message;
		uri = new URI(path);
		return Response.seeOther(uri).build();

	}// addInstitute ends

	/**
	 * To hit the rest api deleting exam
	 *
	 * @see deleteExam
	 * @param examId
	 * @return response
	 * @version 0.1
	 * @author Anand k j
	 */
	@GET
	@Path("/deleteExam/{examId}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response deleteExam(@PathParam("examId") String examId) {

		// calling function to delete exam and setting uri

		try {
			instituteService.deleteExam(examId);
			String path = "http://localhost:8080/OnlineExaminationSystm/deleteExamSuccess.jsp";
			uri = new URI(path);
		} catch (ClassNotFoundException e) {
			logger.info(e.getMessage());
		} catch (URISyntaxException e) {
			logger.info(e.getMessage());
		} catch (SQLException e) {
			logger.info(e.getMessage());
		}
		return Response.seeOther(uri).build();
	}// deleteExam ends

	/**
	 * To hit the rest api deleting student
	 *
	 * @see deleteStudent
	 * @param studentId
	 * @return response
	 * @version 0.1
	 * @author Anand k j
	 */
	@GET
	@Path("/deleteStudent/{studentId}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response deleteStudent(@PathParam("studentId") String studentId) {

		// calling function to delete student and setting uri
		try {
			instituteService.deleteStudent(studentId);
			String path = "http://localhost:8080/OnlineExaminationSystm/deleteStudentSuccess.jsp";
			uri = new URI(path);
		} catch (ClassNotFoundException e) {
			logger.info(e.getMessage());
		} catch (URISyntaxException e) {
			logger.info(e.getMessage());
		} catch (SQLException e) {
			logger.info(e.getMessage());
		}
		return Response.seeOther(uri).build();
	}// deleteStudent ends

}// class ends
