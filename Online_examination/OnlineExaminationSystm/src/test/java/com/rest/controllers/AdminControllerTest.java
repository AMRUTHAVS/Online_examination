/***********************************************************************
                         Altran Technologies Proprietary

This source code is the sole property of Altran Technologies. Any form of utilization
of this source code in whole or in part is  prohibited without  written consent from
Altran Technologies

File Name				     :AdminControllerTest.java
Principal Author			 :Ayushi Srivastava
Subsystem Name               :Core Java Training
Module Name                  :
Date of First Release        :28-October-2020
Author                       :Ayushi Srivastava
Description                  :Test class for Implementation of AdminDao


Change History

Version                     :0.1
Date(DD/MM/YYYY)            :28-October-2020
Modified by                 :Ayushi Srivastava
Description of change       :Initial Version

***********************************************************************/
package com.rest.controllers;

import static org.junit.Assert.*;

import javax.ws.rs.core.Response;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

public class AdminControllerTest {
	// creating Response object
	Response response;
	// creating object of AdminController
	static AdminController adminController;

	/**
	 * To intializing object
	 * 
	 * @throws Exception
	 * @version 0.1
	 * @author Ayushi Srivastava
	 * 
	 */
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		// intializing object
		adminController = new AdminController();
	}

	/**
	 * To nullify object
	 * 
	 * @throws Exception
	 * @version 0.1
	 * @author Ayushi Srivastava
	 * 
	 */
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		adminController = null;
	}

	/**
	 * To test deleteInstitute
	 * 
	 * @see testDeleteInstitute
	 * @throws Exception
	 * @version 0.1
	 * @author Ayushi Srivastava
	 * 
	 */
	@Test
	public void testDeleteInstitute() {
		// checking result
		response = adminController.deleteInstitute("23");
		assertEquals(Response.Status.SEE_OTHER.getStatusCode(), response.getStatus());
	}// testDeleteInstitute

}// class ends
