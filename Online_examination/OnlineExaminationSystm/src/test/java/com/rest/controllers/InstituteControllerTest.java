/***********************************************************************
                         Altran Technologies Proprietary

This source code is the sole property of Altran Technologies. Any form of utilization
of this source code in whole or in part is  prohibited without  written consent from
Altran Technologies

File Name				     :InstituteControllerTest.java
Principal Author			 :Anand k j
Subsystem Name               :Core Java Training
Module Name                  :
Date of First Release        :28-October-2020
Author                       :Anand k j
Description                  :Test class for Implementation of AdminDao


Change History

Version                     :0.1
Date(DD/MM/YYYY)            :28-October-2020
Modified by                 :Anand k j
Description of change       :Initial Version

***********************************************************************/
package com.rest.controllers;

import static org.junit.Assert.*;

import java.net.URISyntaxException;
import java.sql.SQLException;

import javax.ws.rs.core.Response;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

public class InstituteControllerTest {
	// creating object of InstituteController
	static InstituteController ic;
	Response response;

	/**
	 * To initialize object
	 * 
	 * @throws Exception
	 * @version 0.1
	 * @author Anand k j
	 * 
	 */
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		ic = new InstituteController();
	}

	/**
	 * To nullify the object
	 * 
	 * @throws Exception
	 * @version 0.1
	 * @author Anand k j
	 * 
	 */
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		ic = null;
	}

	/**
	 * To test addInstitute
	 * 
	 * @see testAddInstitute
	 * @throws Exception
	 * @version 0.1
	 * @author Anand k j
	 * 
	 */
	@Test
	public void testAddInstitue() throws ClassNotFoundException, SQLException, URISyntaxException {
		// result comparing
		response = ic.addInstitue("dffg", "9879879876", "sdfg", "sdf@gmail.com", "Asdf@123");
		assertEquals(Response.Status.SEE_OTHER.getStatusCode(), response.getStatus());
	}

	/**
	 * To test deleteExam
	 * 
	 * @see testDeleteExam
	 * @throws Exception
	 * @version 0.1
	 * @author Anand k j
	 * 
	 */
	@Test
	public void testDeleteExam() {
		// result comparing
		response = ic.deleteExam("9");
		assertEquals(Response.Status.SEE_OTHER.getStatusCode(), response.getStatus());
	}

	/**
	 * To test deleteStudent
	 * 
	 * @see testDeleteInstitute
	 * @throws Exception
	 * @version 0.1
	 * @author Anand k j
	 * 
	 */
	@Test
	public void testDeleteStudent() {
		response = ic.deleteStudent("26");
		assertEquals(Response.Status.SEE_OTHER.getStatusCode(), response.getStatus());
	}

}// class ends
