/***********************************************************************
                         Altran Technologies Proprietary

This source code is the sole property of Altran Technologies. Any form of utilization
of this source code in whole or in part is  prohibited without  written consent from
Altran Technologies

File Name				     :StudentControllerTest.java
Principal Author			 :Anupriya Gandhi
Subsystem Name               :Core Java Training
Module Name                  :
Date of First Release        :28-October-2020
Author                       :Anupriya Gandhi
Description                  :Test class for Implementation of AdminDao


Change History

Version                     :0.1
Date(DD/MM/YYYY)            :28-October-2020
Modified by                 :Anupriya Gandhi
Description of change       :Initial Version

***********************************************************************/
package com.rest.controllers;

import static org.junit.Assert.*;

import java.net.URISyntaxException;
import java.sql.SQLException;

import javax.ws.rs.core.Response;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

public class StudentControllerTest {
	Response response;
	// creating object of StudentController class
	static StudentController sc;

	/**
	 * To initialize object
	 * 
	 * @throws Exception
	 * @version 0.1
	 * @author Anupriya Gandhi
	 * 
	 */
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		sc = new StudentController();
	}

	/**
	 * To nullify the object
	 * 
	 * @see testDeleteInstitute
	 * @throws Exception
	 * @version 0.1
	 * @author Anupriya Gandhi
	 * 
	 */
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		sc = null;
	}

	/**
	 * To test addStudent
	 * 
	 * @see testDeleteInstitute
	 * @throws Exception
	 * @version 0.1
	 * @author Anupriya Gandhi
	 * 
	 */
	@Test
	public void testAddStudent() throws ClassNotFoundException, SQLException, URISyntaxException {
		response = sc.addStudent("anupriya", "assumption high school", "10", "anu123456@gmail.com", "9989678900",
				"anu@123A");
		assertEquals(Response.Status.SEE_OTHER.getStatusCode(), response.getStatus());
	}

}// class ends
