/***********************************************************************
                         Altran Technologies Proprietary

This source code is the sole property of Altran Technologies. Any form of utilization
of this source code in whole or in part is  prohibited without  written consent from
Altran Technologies

File Name				   :Program1.java
Principal Author			   :Ayushi Srivastava
Subsystem Name                :Core Java Training
Module Name                   :
Date of First Release         :28-October-2020
Author                           : Ayushi Srivastava
Description                :Print Hello World on screen


Change History

Version                      :0.1
Date(DD/MM/YYYY)            :28-October-2020
Modified by                 :Ayushi Srivastava
Description of change       :Initial Version

***********************************************************************/
package com.rest.serviceimplement;

import static org.junit.Assert.*;

import java.sql.SQLException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.rest.service.AdminService;

/**
 * Print Hello World on screen
 * 
 * @return
 * @param
 * @see Program1
 * @version 0.1
 * @author Ayushi Srivastava
 * 
 */
public class AdminServiceImplTest {

	// creating object of AdminDao class
	AdminService adminService;

	/**
	 * To initialize the object and set values to the parameters
	 * 
	 * @return void
	 * @see setUp
	 * @author Ayushi Srivastava
	 */
	@Before
	public void setUp() throws Exception {
		adminService = new AdminServiceImpl();
	}

	/**
	 * To nullify object
	 * 
	 * @author Ayushi Srivastava
	 * @return void
	 * @see tearDown
	 */
	@After
	public void tearDown() throws Exception {
		adminService = null;
	}

	/**
	 * Test case for testing the deleteInstitute.
	 * 
	 * @see testDeleteInstitute
	 * @version 0.1
	 * @author Ayushi Srivastava
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 * 
	 */
	@Test
	public void testDeleteInstitute() throws ClassNotFoundException, SQLException {
		assertEquals(1, adminService.deleteInstitute("36"));

	}

}
