/***********************************************************************
                         Altran Technologies Proprietary

This source code is the sole property of Altran Technologies. Any form of utilization
of this source code in whole or in part is  prohibited without  written consent from
Altran Technologies

File Name				     :LoginServiceImplTest.java
Principal Author			 :Sruthi Suresh
Subsystem Name               :Core Java Training
Module Name                  :
Date of First Release        :28-October-2020
Author                       :Sruthi Suresh
Description                  :Test for Implementation of loginService class


Change History

Version                     :0.1
Date(DD/MM/YYYY)            :28-October-2020
Modified by                 :Sruthi Suresh
Description of change       :Initial Version

 ***********************************************************************/
package com.rest.serviceimplement;

import static org.junit.Assert.*;

import java.sql.SQLException;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import com.rest.service.LoginService;

/**
 * Test for Implementation of loginService class
 *
 * @see LoginServiceImplTest
 * @version 0.1
 * @author Sruthi Suresh
 * @since 28-October-2020
 */
public class LoginServiceImplTest {
	// Creating object of login service.
	static LoginService loginService;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		loginService = new LoginServiceImpl();

	}

	/**
	 * To nullify object
	 * 
	 * @throws Exception
	 * @version 0.1
	 * @author Sruthi Suresh
	 * 
	 */
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		loginService = null;
	}

	/**
	 * Test Method to userLogin
	 * 
	 * @see userLogin
	 * @param userEmail
	 * @param userPass
	 * @return string
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 * @author Sruthi Suresh
	 * 
	 */
	@Test
	public void testUserLogin() throws ClassNotFoundException, SQLException {
		assertEquals("noUser", loginService.userLogin("noUser", "noUser"));
		assertEquals("institute", loginService.userLogin("assumption@gmail.com", "Qwerty@123"));
		assertEquals("student", loginService.userLogin("anupriya@gmail.com", "Qwerty@123"));

	}

}// class ends
