/***********************************************************************
                         Altran Technologies Proprietary

This source code is the sole property of Altran Technologies. Any form of utilization
of this source code in whole or in part is  prohibited without  written consent from
Altran Technologies

File Name				      : StudentDaoImplTest.java
Principal Author			  : Piyush Kumar (4015432)
Subsystem Name                : Online Examination System
Module Name                   :
Date of First Release         : 17-Nov-2020 2:41:02 PM
Author                        : Piyush Kumar
Description                   :


Change History

Version                      : 0.1
Date(DD/MM/YYYY)             : 17-Nov-2020 2:41:02 PM
Modified by                  : Piyush Kumar(4015432)
Description of change        : Initial Version

 ***********************************************************************/
package com.rest.daoimplement;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.sql.SQLException;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import com.rest.dao.StudentDao;
import com.rest.model.Student;

/**
 * Tests the methods of studentDaoImpl class.
 * 
 * @see StudentDaoImplTest.java
 * @version 0.1
 * @author Anupriya Gandhi
 * 
 */
public class StudentDaoImplTest {

	// Creating the reference variables.

	static StudentDao studentDao;
	static Student student;

	/**
	 * Initializing the object
	 * 
	 * @param
	 * @return void
	 * @see setUpBeforeClass
	 * @version 0.1
	 * @author Anupriya Gandhi
	 * 
	 */
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {

		studentDao = new StudentDaoImpl();
		student = new Student();

		student.setStudName("aahwin");
		student.setStudClass("8");
		student.setStudEmail("ashwin@gmail.com");
		student.setStudMob("8100931002");
		student.setStudPass("Anu@3210");
		student.setStudInstitution("assumption high school");

	}

	/**
	 * Nullify the object
	 * 
	 * @param
	 * @return void
	 * @see tearDownAfterClass
	 * @version 0.1
	 * @author Anupriya Gandhi
	 * 
	 */
	@AfterClass
	public static void tearDownAfterClass() throws Exception {

		studentDao = null;
	}

	/**
	 * To test registerStudent method.
	 * 
	 * @see testResgisterStudent
	 * @version 0.1
	 * @author Sruthi Suresh
	 * 
	 */
	@Test
	public void testResgisterStudent() throws ClassNotFoundException, SQLException {

		assertEquals(1, studentDao.registerStudent(student));

	}

	/**
	 * To test registerStudent method.
	 * 
	 * @see testResgisterStudentException
	 * @version 0.1
	 * @author Sruthi Suresh
	 * 
	 */
	@Test
	public void testResgisterStudentException() throws ClassNotFoundException, SQLException {

		assertEquals(0, studentDao.registerStudent(student));

	}

	/**
	 * To test getStudent Method.
	 * 
	 * @see testGetStudent
	 * @version 0.1
	 * @author Anupriya Gandhi
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 * 
	 */
	@Test
	public void testGetStudent() throws ClassNotFoundException, SQLException {

		assertNotNull(studentDao.getStudent("Anu@gmail.com"));

	}

	/**
	 * To test viewSchedule method.
	 * 
	 * @see testViewSchedule
	 * @version 0.1
	 * @author Anupriya Gandhi
	 * 
	 */
	@Test
	public void testViewSchedule() throws ClassNotFoundException, SQLException {

		// check result
		assertNotNull(studentDao.viewSchedule("6", "8"));

	}

	/**
	 * Description about the Method.
	 * 
	 * @see testGetResult
	 * @version 0.1
	 * @author Anupriya Gandhi
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 * 
	 */
	@Test
	public void testGetResult() throws ClassNotFoundException, SQLException {

		// compare result
		assertNotNull(studentDao.getResult("1"));

	}

	/**
	 * To test viewReport method.
	 * 
	 * @see testViewReport
	 * @version 0.1
	 * @author Anupriya Gandhi
	 * 
	 */
	@Test
	public void testViewReport() throws ClassNotFoundException, SQLException {

		assertNotNull(studentDao.viewReport("3"));

	}

	/**
	 * To test examToAttend method.
	 * 
	 * @see testAttendExam
	 * @version 0.1
	 * @author Piyush Kumar
	 * 
	 */
	@Test
	public void testToAttendExam() throws ClassNotFoundException, SQLException {

		assertNotNull(studentDao.examToAttend("2", "9"));

	}

	/**
	 * To test attendExam Method.
	 * 
	 * @see testAttendExam
	 * @version 0.1
	 * @author Piyush Kumar
	 * 
	 */
	@Test
	public void testAttendExam() throws ClassNotFoundException, SQLException {

		assertNotNull(studentDao.attendExam("2"));
	}

	/**
	 * To test saveResult Method.
	 * 
	 * @see testSaveResultPass
	 * @version 0.1
	 * @author Piyush Kumar
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 * 
	 */
	@Test
	public void testSaveResultPass() throws ClassNotFoundException, SQLException {

		assertEquals(1, studentDao.saveResult("2", "3", 10, 8, "pass"));
	}

	/**
	 * To test saveResult Method if fail.
	 * 
	 * @see testSaveResultFail
	 * @version 0.1
	 * @author Piyush Kumar
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 * 
	 */
	@Test
	public void testSaveResultFail() throws ClassNotFoundException, SQLException {

		assertEquals(1, studentDao.saveResult("2", "3", 10, 2, "fail"));
	}

}
