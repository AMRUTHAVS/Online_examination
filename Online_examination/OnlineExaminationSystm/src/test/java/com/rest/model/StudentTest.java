/***********************************************************************
                         Altran Technologies Proprietary

This source code is the sole property of Altran Technologies. Any form of utilization
of this source code in whole or in part is  prohibited without  written consent from
Altran Technologies

File Name				     :StudentTest.java
Principal Author			 :Sruthi Suresh
Subsystem Name               :Core Java Training
Module Name                  :
Date of First Release        :28-October-2020
Author                       :Sruthi Suresh
Description                  :Test Pojo class of Students


Change History

Version                     :0.1
Date(DD/MM/YYYY)            :28-October-2020
Modified by                 :Sruthi Suresh
Description of change       :Initial Version

***********************************************************************/
package com.rest.model;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

/**
 * To test getters and setters
 * 
 * @see StudentTest
 * @version 0.1
 * @author Sruthi Suresh
 * 
 */
public class StudentTest {
	// Creating object of student
	static Student student;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		// Initialising and setting up values
		student = new Student();
		student.setStudName("Sru");
		student.setStudInstitution("cusat");
		student.setStudEmail("sru@gmail.com");
		student.setStudPass("sru123");
		student.setStudMob("9747685633");
		student.setStudClass("8");
	}

	/**
	 * To nullify object
	 *
	 * @version 0.1
	 * @author Sruthi Suresh
	 * 
	 */

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		student = null;
	}

	/**
	 * To test getter methods
	 *
	 * @version 0.1
	 * @author Sruthi Suresh
	 * 
	 */

	@Test
	public void testGetStudDetails() {
		assertEquals("Sru", student.getStudName());
		assertEquals("cusat", student.getStudInstitution());
		assertEquals("sru@gmail.com", student.getStudEmail());
		assertEquals("sru123", student.getStudPass());
		assertEquals("9747685633", student.getStudMob());
		assertEquals("8", student.getStudClass());
	}

}// class ends