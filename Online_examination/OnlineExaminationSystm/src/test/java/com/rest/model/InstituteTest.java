/***********************************************************************
                         Altran Technologies Proprietary

This source code is the sole property of Altran Technologies. Any form of utilization
of this source code in whole or in part is  prohibited without  written consent from
Altran Technologies

File Name				     :InstituteTest.java
Principal Author			 :Sruthi Suresh
Subsystem Name               :Core Java Training
Module Name                  :
Date of First Release        :28-October-2020
Author                       :Sruthi Suresh
Description                  :Test Pojo class of Institutes


Change History

Version                     :0.1
Date(DD/MM/YYYY)            :28-October-2020
Modified by                 :Sruthi Suresh
Description of change       :Initial Version

 ***********************************************************************/
package com.rest.model;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

/**
 * To test getters and setters
 *
 * @see InstituteTest
 * @version 0.1
 * @author Sruthi Suresh
 * 
 */
public class InstituteTest {
	// Creating object of Institutes
	static Institute institute;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		// Initialising and setting up values
		institute = new Institute();
		institute.setInstName("cusat");
		institute.setInstEmail("sru@gmail.com");
		institute.setInstPhone("9747685633");
		institute.setInstAddress("Rosevilla");
		institute.setInstPass("sru123");
	}

	/**
	 * To nullify object
	 *
	 * @version 0.1
	 * @author Sruthi Suresh
	 * 
	 */
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		institute = null;
	}

	/**
	 * To test getter methods
	 *
	 * @version 0.1
	 * @author Sruthi Suresh
	 * 
	 */
	@Test
	public void testGetInstDetails() {
		assertEquals("cusat", institute.getInstName());
		assertEquals("sru@gmail.com", institute.getInstEmail());
		assertEquals("9747685633", institute.getInstPhone());
		assertEquals("Rosevilla", institute.getInstAddress());
		assertEquals("sru123", institute.getInstPass());

	}
}// class ends
